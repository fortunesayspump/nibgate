"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/@mozilla/readability/Readability.js
  var require_Readability = __commonJS({
    "node_modules/@mozilla/readability/Readability.js"(exports, module) {
      function Readability2(doc, options) {
        if (options && options.documentElement) {
          doc = options;
          options = arguments[2];
        } else if (!doc || !doc.documentElement) {
          throw new Error(
            "First argument to Readability constructor should be a document object."
          );
        }
        options = options || {};
        this._doc = doc;
        this._docJSDOMParser = this._doc.firstChild.__JSDOMParser__;
        this._articleTitle = null;
        this._articleByline = null;
        this._articleDir = null;
        this._articleSiteName = null;
        this._attempts = [];
        this._metadata = {};
        this._debug = !!options.debug;
        this._maxElemsToParse = options.maxElemsToParse || this.DEFAULT_MAX_ELEMS_TO_PARSE;
        this._nbTopCandidates = options.nbTopCandidates || this.DEFAULT_N_TOP_CANDIDATES;
        this._charThreshold = options.charThreshold || this.DEFAULT_CHAR_THRESHOLD;
        this._classesToPreserve = this.CLASSES_TO_PRESERVE.concat(
          options.classesToPreserve || []
        );
        this._keepClasses = !!options.keepClasses;
        this._serializer = options.serializer || function(el) {
          return el.innerHTML;
        };
        this._disableJSONLD = !!options.disableJSONLD;
        this._allowedVideoRegex = options.allowedVideoRegex || this.REGEXPS.videos;
        this._linkDensityModifier = options.linkDensityModifier || 0;
        this._flags = this.FLAG_STRIP_UNLIKELYS | this.FLAG_WEIGHT_CLASSES | this.FLAG_CLEAN_CONDITIONALLY;
        if (this._debug) {
          let logNode = function(node) {
            if (node.nodeType == node.TEXT_NODE) {
              return `${node.nodeName} ("${node.textContent}")`;
            }
            let attrPairs = Array.from(node.attributes || [], function(attr) {
              return `${attr.name}="${attr.value}"`;
            }).join(" ");
            return `<${node.localName} ${attrPairs}>`;
          };
          this.log = function() {
            if (typeof console !== "undefined") {
              let args = Array.from(arguments, (arg) => {
                if (arg && arg.nodeType == this.ELEMENT_NODE) {
                  return logNode(arg);
                }
                return arg;
              });
              args.unshift("Reader: (Readability)");
              console.log(...args);
            } else if (typeof dump !== "undefined") {
              var msg = Array.prototype.map.call(arguments, function(x) {
                return x && x.nodeName ? logNode(x) : x;
              }).join(" ");
              dump("Reader: (Readability) " + msg + "\n");
            }
          };
        } else {
          this.log = function() {
          };
        }
      }
      Readability2.prototype = {
        FLAG_STRIP_UNLIKELYS: 1,
        FLAG_WEIGHT_CLASSES: 2,
        FLAG_CLEAN_CONDITIONALLY: 4,
        // https://developer.mozilla.org/en-US/docs/Web/API/Node/nodeType
        ELEMENT_NODE: 1,
        TEXT_NODE: 3,
        // Max number of nodes supported by this parser. Default: 0 (no limit)
        DEFAULT_MAX_ELEMS_TO_PARSE: 0,
        // The number of top candidates to consider when analysing how
        // tight the competition is among candidates.
        DEFAULT_N_TOP_CANDIDATES: 5,
        // Element tags to score by default.
        DEFAULT_TAGS_TO_SCORE: "section,h2,h3,h4,h5,h6,p,td,pre".toUpperCase().split(","),
        // The default number of chars an article must have in order to return a result
        DEFAULT_CHAR_THRESHOLD: 500,
        // All of the regular expressions in use within readability.
        // Defined up here so we don't instantiate them repeatedly in loops.
        REGEXPS: {
          // NOTE: These two regular expressions are duplicated in
          // Readability-readerable.js. Please keep both copies in sync.
          unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
          okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i,
          positive: /article|body|content|entry|hentry|h-entry|main|page|pagination|post|text|blog|story/i,
          negative: /-ad-|hidden|^hid$| hid$| hid |^hid |banner|combx|comment|com-|contact|footer|gdpr|masthead|media|meta|outbrain|promo|related|scroll|share|shoutbox|sidebar|skyscraper|sponsor|shopping|tags|widget/i,
          extraneous: /print|archive|comment|discuss|e[\-]?mail|share|reply|all|login|sign|single|utility/i,
          byline: /byline|author|dateline|writtenby|p-author/i,
          replaceFonts: /<(\/?)font[^>]*>/gi,
          normalize: /\s{2,}/g,
          videos: /\/\/(www\.)?((dailymotion|youtube|youtube-nocookie|player\.vimeo|v\.qq)\.com|(archive|upload\.wikimedia)\.org|player\.twitch\.tv)/i,
          shareElements: /(\b|_)(share|sharedaddy)(\b|_)/i,
          nextLink: /(next|weiter|continue|>([^\|]|$)|»([^\|]|$))/i,
          prevLink: /(prev|earl|old|new|<|«)/i,
          tokenize: /\W+/g,
          whitespace: /^\s*$/,
          hasContent: /\S$/,
          hashUrl: /^#.+/,
          srcsetUrl: /(\S+)(\s+[\d.]+[xw])?(\s*(?:,|$))/g,
          b64DataUrl: /^data:\s*([^\s;,]+)\s*;\s*base64\s*,/i,
          // Commas as used in Latin, Sindhi, Chinese and various other scripts.
          // see: https://en.wikipedia.org/wiki/Comma#Comma_variants
          commas: /\u002C|\u060C|\uFE50|\uFE10|\uFE11|\u2E41|\u2E34|\u2E32|\uFF0C/g,
          // See: https://schema.org/Article
          jsonLdArticleTypes: /^Article|AdvertiserContentArticle|NewsArticle|AnalysisNewsArticle|AskPublicNewsArticle|BackgroundNewsArticle|OpinionNewsArticle|ReportageNewsArticle|ReviewNewsArticle|Report|SatiricalArticle|ScholarlyArticle|MedicalScholarlyArticle|SocialMediaPosting|BlogPosting|LiveBlogPosting|DiscussionForumPosting|TechArticle|APIReference$/,
          // used to see if a node's content matches words commonly used for ad blocks or loading indicators
          adWords: /^(ad(vertising|vertisement)?|pub(licité)?|werb(ung)?|广告|Реклама|Anuncio)$/iu,
          loadingWords: /^((loading|正在加载|Загрузка|chargement|cargando)(…|\.\.\.)?)$/iu
        },
        UNLIKELY_ROLES: [
          "menu",
          "menubar",
          "complementary",
          "navigation",
          "alert",
          "alertdialog",
          "dialog"
        ],
        DIV_TO_P_ELEMS: /* @__PURE__ */ new Set([
          "BLOCKQUOTE",
          "DL",
          "DIV",
          "IMG",
          "OL",
          "P",
          "PRE",
          "TABLE",
          "UL"
        ]),
        ALTER_TO_DIV_EXCEPTIONS: ["DIV", "ARTICLE", "SECTION", "P", "OL", "UL"],
        PRESENTATIONAL_ATTRIBUTES: [
          "align",
          "background",
          "bgcolor",
          "border",
          "cellpadding",
          "cellspacing",
          "frame",
          "hspace",
          "rules",
          "style",
          "valign",
          "vspace"
        ],
        DEPRECATED_SIZE_ATTRIBUTE_ELEMS: ["TABLE", "TH", "TD", "HR", "PRE"],
        // The commented out elements qualify as phrasing content but tend to be
        // removed by readability when put into paragraphs, so we ignore them here.
        PHRASING_ELEMS: [
          // "CANVAS", "IFRAME", "SVG", "VIDEO",
          "ABBR",
          "AUDIO",
          "B",
          "BDO",
          "BR",
          "BUTTON",
          "CITE",
          "CODE",
          "DATA",
          "DATALIST",
          "DFN",
          "EM",
          "EMBED",
          "I",
          "IMG",
          "INPUT",
          "KBD",
          "LABEL",
          "MARK",
          "MATH",
          "METER",
          "NOSCRIPT",
          "OBJECT",
          "OUTPUT",
          "PROGRESS",
          "Q",
          "RUBY",
          "SAMP",
          "SCRIPT",
          "SELECT",
          "SMALL",
          "SPAN",
          "STRONG",
          "SUB",
          "SUP",
          "TEXTAREA",
          "TIME",
          "VAR",
          "WBR"
        ],
        // These are the classes that readability sets itself.
        CLASSES_TO_PRESERVE: ["page"],
        // These are the list of HTML entities that need to be escaped.
        HTML_ESCAPE_MAP: {
          lt: "<",
          gt: ">",
          amp: "&",
          quot: '"',
          apos: "'"
        },
        /**
         * Run any post-process modifications to article content as necessary.
         *
         * @param Element
         * @return void
         **/
        _postProcessContent(articleContent) {
          this._fixRelativeUris(articleContent);
          this._simplifyNestedElements(articleContent);
          if (!this._keepClasses) {
            this._cleanClasses(articleContent);
          }
        },
        /**
         * Iterates over a NodeList, calls `filterFn` for each node and removes node
         * if function returned `true`.
         *
         * If function is not passed, removes all the nodes in node list.
         *
         * @param NodeList nodeList The nodes to operate on
         * @param Function filterFn the function to use as a filter
         * @return void
         */
        _removeNodes(nodeList, filterFn) {
          if (this._docJSDOMParser && nodeList._isLiveNodeList) {
            throw new Error("Do not pass live node lists to _removeNodes");
          }
          for (var i = nodeList.length - 1; i >= 0; i--) {
            var node = nodeList[i];
            var parentNode = node.parentNode;
            if (parentNode) {
              if (!filterFn || filterFn.call(this, node, i, nodeList)) {
                parentNode.removeChild(node);
              }
            }
          }
        },
        /**
         * Iterates over a NodeList, and calls _setNodeTag for each node.
         *
         * @param NodeList nodeList The nodes to operate on
         * @param String newTagName the new tag name to use
         * @return void
         */
        _replaceNodeTags(nodeList, newTagName) {
          if (this._docJSDOMParser && nodeList._isLiveNodeList) {
            throw new Error("Do not pass live node lists to _replaceNodeTags");
          }
          for (const node of nodeList) {
            this._setNodeTag(node, newTagName);
          }
        },
        /**
         * Iterate over a NodeList, which doesn't natively fully implement the Array
         * interface.
         *
         * For convenience, the current object context is applied to the provided
         * iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return void
         */
        _forEachNode(nodeList, fn) {
          Array.prototype.forEach.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, and return the first node that passes
         * the supplied test function
         *
         * For convenience, the current object context is applied to the provided
         * test function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The test function.
         * @return void
         */
        _findNode(nodeList, fn) {
          return Array.prototype.find.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, return true if any of the provided iterate
         * function calls returns true, false otherwise.
         *
         * For convenience, the current object context is applied to the
         * provided iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return Boolean
         */
        _someNode(nodeList, fn) {
          return Array.prototype.some.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, return true if all of the provided iterate
         * function calls return true, false otherwise.
         *
         * For convenience, the current object context is applied to the
         * provided iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return Boolean
         */
        _everyNode(nodeList, fn) {
          return Array.prototype.every.call(nodeList, fn, this);
        },
        _getAllNodesWithTag(node, tagNames) {
          if (node.querySelectorAll) {
            return node.querySelectorAll(tagNames.join(","));
          }
          return [].concat.apply(
            [],
            tagNames.map(function(tag) {
              var collection = node.getElementsByTagName(tag);
              return Array.isArray(collection) ? collection : Array.from(collection);
            })
          );
        },
        /**
         * Removes the class="" attribute from every element in the given
         * subtree, except those that match CLASSES_TO_PRESERVE and
         * the classesToPreserve array from the options object.
         *
         * @param Element
         * @return void
         */
        _cleanClasses(node) {
          var classesToPreserve = this._classesToPreserve;
          var className = (node.getAttribute("class") || "").split(/\s+/).filter((cls) => classesToPreserve.includes(cls)).join(" ");
          if (className) {
            node.setAttribute("class", className);
          } else {
            node.removeAttribute("class");
          }
          for (node = node.firstElementChild; node; node = node.nextElementSibling) {
            this._cleanClasses(node);
          }
        },
        /**
         * Tests whether a string is a URL or not.
         *
         * @param {string} str The string to test
         * @return {boolean} true if str is a URL, false if not
         */
        _isUrl(str) {
          try {
            new URL(str);
            return true;
          } catch {
            return false;
          }
        },
        /**
         * Converts each <a> and <img> uri in the given element to an absolute URI,
         * ignoring #ref URIs.
         *
         * @param Element
         * @return void
         */
        _fixRelativeUris(articleContent) {
          var baseURI = this._doc.baseURI;
          var documentURI = this._doc.documentURI;
          function toAbsoluteURI(uri) {
            if (baseURI == documentURI && uri.charAt(0) == "#") {
              return uri;
            }
            try {
              return new URL(uri, baseURI).href;
            } catch (ex) {
            }
            return uri;
          }
          var links = this._getAllNodesWithTag(articleContent, ["a"]);
          this._forEachNode(links, function(link) {
            var href = link.getAttribute("href");
            if (href) {
              if (href.indexOf("javascript:") === 0) {
                if (link.childNodes.length === 1 && link.childNodes[0].nodeType === this.TEXT_NODE) {
                  var text = this._doc.createTextNode(link.textContent);
                  link.parentNode.replaceChild(text, link);
                } else {
                  var container = this._doc.createElement("span");
                  while (link.firstChild) {
                    container.appendChild(link.firstChild);
                  }
                  link.parentNode.replaceChild(container, link);
                }
              } else {
                link.setAttribute("href", toAbsoluteURI(href));
              }
            }
          });
          var medias = this._getAllNodesWithTag(articleContent, [
            "img",
            "picture",
            "figure",
            "video",
            "audio",
            "source"
          ]);
          this._forEachNode(medias, function(media) {
            var src = media.getAttribute("src");
            var poster = media.getAttribute("poster");
            var srcset = media.getAttribute("srcset");
            if (src) {
              media.setAttribute("src", toAbsoluteURI(src));
            }
            if (poster) {
              media.setAttribute("poster", toAbsoluteURI(poster));
            }
            if (srcset) {
              var newSrcset = srcset.replace(
                this.REGEXPS.srcsetUrl,
                function(_, p1, p2, p3) {
                  return toAbsoluteURI(p1) + (p2 || "") + p3;
                }
              );
              media.setAttribute("srcset", newSrcset);
            }
          });
        },
        _simplifyNestedElements(articleContent) {
          var node = articleContent;
          while (node) {
            if (node.parentNode && ["DIV", "SECTION"].includes(node.tagName) && !(node.id && node.id.startsWith("readability"))) {
              if (this._isElementWithoutContent(node)) {
                node = this._removeAndGetNext(node);
                continue;
              } else if (this._hasSingleTagInsideElement(node, "DIV") || this._hasSingleTagInsideElement(node, "SECTION")) {
                var child = node.children[0];
                for (var i = 0; i < node.attributes.length; i++) {
                  child.setAttributeNode(node.attributes[i].cloneNode());
                }
                node.parentNode.replaceChild(child, node);
                node = child;
                continue;
              }
            }
            node = this._getNextNode(node);
          }
        },
        /**
         * Get the article title as an H1.
         *
         * @return string
         **/
        _getArticleTitle() {
          var doc = this._doc;
          var curTitle = "";
          var origTitle = "";
          try {
            curTitle = origTitle = doc.title.trim();
            if (typeof curTitle !== "string") {
              curTitle = origTitle = this._getInnerText(
                doc.getElementsByTagName("title")[0]
              );
            }
          } catch (e) {
          }
          var titleHadHierarchicalSeparators = false;
          function wordCount(str) {
            return str.split(/\s+/).length;
          }
          if (/ [\|\-\\\/>»] /.test(curTitle)) {
            titleHadHierarchicalSeparators = / [\\\/>»] /.test(curTitle);
            let allSeparators = Array.from(origTitle.matchAll(/ [\|\-\\\/>»] /gi));
            curTitle = origTitle.substring(0, allSeparators.pop().index);
            if (wordCount(curTitle) < 3) {
              curTitle = origTitle.replace(/^[^\|\-\\\/>»]*[\|\-\\\/>»]/gi, "");
            }
          } else if (curTitle.includes(": ")) {
            var headings = this._getAllNodesWithTag(doc, ["h1", "h2"]);
            var trimmedTitle = curTitle.trim();
            var match = this._someNode(headings, function(heading) {
              return heading.textContent.trim() === trimmedTitle;
            });
            if (!match) {
              curTitle = origTitle.substring(origTitle.lastIndexOf(":") + 1);
              if (wordCount(curTitle) < 3) {
                curTitle = origTitle.substring(origTitle.indexOf(":") + 1);
              } else if (wordCount(origTitle.substr(0, origTitle.indexOf(":"))) > 5) {
                curTitle = origTitle;
              }
            }
          } else if (curTitle.length > 150 || curTitle.length < 15) {
            var hOnes = doc.getElementsByTagName("h1");
            if (hOnes.length === 1) {
              curTitle = this._getInnerText(hOnes[0]);
            }
          }
          curTitle = curTitle.trim().replace(this.REGEXPS.normalize, " ");
          var curTitleWordCount = wordCount(curTitle);
          if (curTitleWordCount <= 4 && (!titleHadHierarchicalSeparators || curTitleWordCount != wordCount(origTitle.replace(/[\|\-\\\/>»]+/g, "")) - 1)) {
            curTitle = origTitle;
          }
          return curTitle;
        },
        /**
         * Prepare the HTML document for readability to scrape it.
         * This includes things like stripping javascript, CSS, and handling terrible markup.
         *
         * @return void
         **/
        _prepDocument() {
          var doc = this._doc;
          this._removeNodes(this._getAllNodesWithTag(doc, ["style"]));
          if (doc.body) {
            this._replaceBrs(doc.body);
          }
          this._replaceNodeTags(this._getAllNodesWithTag(doc, ["font"]), "SPAN");
        },
        /**
         * Finds the next node, starting from the given node, and ignoring
         * whitespace in between. If the given node is an element, the same node is
         * returned.
         */
        _nextNode(node) {
          var next = node;
          while (next && next.nodeType != this.ELEMENT_NODE && this.REGEXPS.whitespace.test(next.textContent)) {
            next = next.nextSibling;
          }
          return next;
        },
        /**
         * Replaces 2 or more successive <br> elements with a single <p>.
         * Whitespace between <br> elements are ignored. For example:
         *   <div>foo<br>bar<br> <br><br>abc</div>
         * will become:
         *   <div>foo<br>bar<p>abc</p></div>
         */
        _replaceBrs(elem) {
          this._forEachNode(this._getAllNodesWithTag(elem, ["br"]), function(br) {
            var next = br.nextSibling;
            var replaced = false;
            while ((next = this._nextNode(next)) && next.tagName == "BR") {
              replaced = true;
              var brSibling = next.nextSibling;
              next.remove();
              next = brSibling;
            }
            if (replaced) {
              var p = this._doc.createElement("p");
              br.parentNode.replaceChild(p, br);
              next = p.nextSibling;
              while (next) {
                if (next.tagName == "BR") {
                  var nextElem = this._nextNode(next.nextSibling);
                  if (nextElem && nextElem.tagName == "BR") {
                    break;
                  }
                }
                if (!this._isPhrasingContent(next)) {
                  break;
                }
                var sibling = next.nextSibling;
                p.appendChild(next);
                next = sibling;
              }
              while (p.lastChild && this._isWhitespace(p.lastChild)) {
                p.lastChild.remove();
              }
              if (p.parentNode.tagName === "P") {
                this._setNodeTag(p.parentNode, "DIV");
              }
            }
          });
        },
        _setNodeTag(node, tag) {
          this.log("_setNodeTag", node, tag);
          if (this._docJSDOMParser) {
            node.localName = tag.toLowerCase();
            node.tagName = tag.toUpperCase();
            return node;
          }
          var replacement = node.ownerDocument.createElement(tag);
          while (node.firstChild) {
            replacement.appendChild(node.firstChild);
          }
          node.parentNode.replaceChild(replacement, node);
          if (node.readability) {
            replacement.readability = node.readability;
          }
          for (var i = 0; i < node.attributes.length; i++) {
            replacement.setAttributeNode(node.attributes[i].cloneNode());
          }
          return replacement;
        },
        /**
         * Prepare the article node for display. Clean out any inline styles,
         * iframes, forms, strip extraneous <p> tags, etc.
         *
         * @param Element
         * @return void
         **/
        _prepArticle(articleContent) {
          this._cleanStyles(articleContent);
          this._markDataTables(articleContent);
          this._fixLazyImages(articleContent);
          this._cleanConditionally(articleContent, "form");
          this._cleanConditionally(articleContent, "fieldset");
          this._clean(articleContent, "object");
          this._clean(articleContent, "embed");
          this._clean(articleContent, "footer");
          this._clean(articleContent, "link");
          this._clean(articleContent, "aside");
          var shareElementThreshold = this.DEFAULT_CHAR_THRESHOLD;
          this._forEachNode(articleContent.children, function(topCandidate) {
            this._cleanMatchedNodes(topCandidate, function(node, matchString) {
              return this.REGEXPS.shareElements.test(matchString) && node.textContent.length < shareElementThreshold;
            });
          });
          this._clean(articleContent, "iframe");
          this._clean(articleContent, "input");
          this._clean(articleContent, "textarea");
          this._clean(articleContent, "select");
          this._clean(articleContent, "button");
          this._cleanHeaders(articleContent);
          this._cleanConditionally(articleContent, "table");
          this._cleanConditionally(articleContent, "ul");
          this._cleanConditionally(articleContent, "div");
          this._replaceNodeTags(
            this._getAllNodesWithTag(articleContent, ["h1"]),
            "h2"
          );
          this._removeNodes(
            this._getAllNodesWithTag(articleContent, ["p"]),
            function(paragraph) {
              var contentElementCount = this._getAllNodesWithTag(paragraph, [
                "img",
                "embed",
                "object",
                "iframe"
              ]).length;
              return contentElementCount === 0 && !this._getInnerText(paragraph, false);
            }
          );
          this._forEachNode(
            this._getAllNodesWithTag(articleContent, ["br"]),
            function(br) {
              var next = this._nextNode(br.nextSibling);
              if (next && next.tagName == "P") {
                br.remove();
              }
            }
          );
          this._forEachNode(
            this._getAllNodesWithTag(articleContent, ["table"]),
            function(table) {
              var tbody = this._hasSingleTagInsideElement(table, "TBODY") ? table.firstElementChild : table;
              if (this._hasSingleTagInsideElement(tbody, "TR")) {
                var row = tbody.firstElementChild;
                if (this._hasSingleTagInsideElement(row, "TD")) {
                  var cell = row.firstElementChild;
                  cell = this._setNodeTag(
                    cell,
                    this._everyNode(cell.childNodes, this._isPhrasingContent) ? "P" : "DIV"
                  );
                  table.parentNode.replaceChild(cell, table);
                }
              }
            }
          );
        },
        /**
         * Initialize a node with the readability object. Also checks the
         * className/id for special names to add to its score.
         *
         * @param Element
         * @return void
         **/
        _initializeNode(node) {
          node.readability = { contentScore: 0 };
          switch (node.tagName) {
            case "DIV":
              node.readability.contentScore += 5;
              break;
            case "PRE":
            case "TD":
            case "BLOCKQUOTE":
              node.readability.contentScore += 3;
              break;
            case "ADDRESS":
            case "OL":
            case "UL":
            case "DL":
            case "DD":
            case "DT":
            case "LI":
            case "FORM":
              node.readability.contentScore -= 3;
              break;
            case "H1":
            case "H2":
            case "H3":
            case "H4":
            case "H5":
            case "H6":
            case "TH":
              node.readability.contentScore -= 5;
              break;
          }
          node.readability.contentScore += this._getClassWeight(node);
        },
        _removeAndGetNext(node) {
          var nextNode = this._getNextNode(node, true);
          node.remove();
          return nextNode;
        },
        /**
         * Traverse the DOM from node to node, starting at the node passed in.
         * Pass true for the second parameter to indicate this node itself
         * (and its kids) are going away, and we want the next node over.
         *
         * Calling this in a loop will traverse the DOM depth-first.
         *
         * @param {Element} node
         * @param {boolean} ignoreSelfAndKids
         * @return {Element}
         */
        _getNextNode(node, ignoreSelfAndKids) {
          if (!ignoreSelfAndKids && node.firstElementChild) {
            return node.firstElementChild;
          }
          if (node.nextElementSibling) {
            return node.nextElementSibling;
          }
          do {
            node = node.parentNode;
          } while (node && !node.nextElementSibling);
          return node && node.nextElementSibling;
        },
        // compares second text to first one
        // 1 = same text, 0 = completely different text
        // works the way that it splits both texts into words and then finds words that are unique in second text
        // the result is given by the lower length of unique parts
        _textSimilarity(textA, textB) {
          var tokensA = textA.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
          var tokensB = textB.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
          if (!tokensA.length || !tokensB.length) {
            return 0;
          }
          var uniqTokensB = tokensB.filter((token) => !tokensA.includes(token));
          var distanceB = uniqTokensB.join(" ").length / tokensB.join(" ").length;
          return 1 - distanceB;
        },
        /**
         * Checks whether an element node contains a valid byline
         *
         * @param node {Element}
         * @param matchString {string}
         * @return boolean
         */
        _isValidByline(node, matchString) {
          var rel = node.getAttribute("rel");
          var itemprop = node.getAttribute("itemprop");
          var bylineLength = node.textContent.trim().length;
          return (rel === "author" || itemprop && itemprop.includes("author") || this.REGEXPS.byline.test(matchString)) && !!bylineLength && bylineLength < 100;
        },
        _getNodeAncestors(node, maxDepth) {
          maxDepth = maxDepth || 0;
          var i = 0, ancestors = [];
          while (node.parentNode) {
            ancestors.push(node.parentNode);
            if (maxDepth && ++i === maxDepth) {
              break;
            }
            node = node.parentNode;
          }
          return ancestors;
        },
        /***
         * grabArticle - Using a variety of metrics (content score, classname, element types), find the content that is
         *         most likely to be the stuff a user wants to read. Then return it wrapped up in a div.
         *
         * @param page a document to run upon. Needs to be a full document, complete with body.
         * @return Element
         **/
        /* eslint-disable-next-line complexity */
        _grabArticle(page) {
          this.log("**** grabArticle ****");
          var doc = this._doc;
          var isPaging = page !== null;
          page = page ? page : this._doc.body;
          if (!page) {
            this.log("No body found in document. Abort.");
            return null;
          }
          var pageCacheHtml = page.innerHTML;
          while (true) {
            this.log("Starting grabArticle loop");
            var stripUnlikelyCandidates = this._flagIsActive(
              this.FLAG_STRIP_UNLIKELYS
            );
            var elementsToScore = [];
            var node = this._doc.documentElement;
            let shouldRemoveTitleHeader = true;
            while (node) {
              if (node.tagName === "HTML") {
                this._articleLang = node.getAttribute("lang");
              }
              var matchString = node.className + " " + node.id;
              if (!this._isProbablyVisible(node)) {
                this.log("Removing hidden node - " + matchString);
                node = this._removeAndGetNext(node);
                continue;
              }
              if (node.getAttribute("aria-modal") == "true" && node.getAttribute("role") == "dialog") {
                node = this._removeAndGetNext(node);
                continue;
              }
              if (!this._articleByline && !this._metadata.byline && this._isValidByline(node, matchString)) {
                var endOfSearchMarkerNode = this._getNextNode(node, true);
                var next = this._getNextNode(node);
                var itemPropNameNode = null;
                while (next && next != endOfSearchMarkerNode) {
                  var itemprop = next.getAttribute("itemprop");
                  if (itemprop && itemprop.includes("name")) {
                    itemPropNameNode = next;
                    break;
                  } else {
                    next = this._getNextNode(next);
                  }
                }
                this._articleByline = (itemPropNameNode ?? node).textContent.trim();
                node = this._removeAndGetNext(node);
                continue;
              }
              if (shouldRemoveTitleHeader && this._headerDuplicatesTitle(node)) {
                this.log(
                  "Removing header: ",
                  node.textContent.trim(),
                  this._articleTitle.trim()
                );
                shouldRemoveTitleHeader = false;
                node = this._removeAndGetNext(node);
                continue;
              }
              if (stripUnlikelyCandidates) {
                if (this.REGEXPS.unlikelyCandidates.test(matchString) && !this.REGEXPS.okMaybeItsACandidate.test(matchString) && !this._hasAncestorTag(node, "table") && !this._hasAncestorTag(node, "code") && node.tagName !== "BODY" && node.tagName !== "A") {
                  this.log("Removing unlikely candidate - " + matchString);
                  node = this._removeAndGetNext(node);
                  continue;
                }
                if (this.UNLIKELY_ROLES.includes(node.getAttribute("role"))) {
                  this.log(
                    "Removing content with role " + node.getAttribute("role") + " - " + matchString
                  );
                  node = this._removeAndGetNext(node);
                  continue;
                }
              }
              if ((node.tagName === "DIV" || node.tagName === "SECTION" || node.tagName === "HEADER" || node.tagName === "H1" || node.tagName === "H2" || node.tagName === "H3" || node.tagName === "H4" || node.tagName === "H5" || node.tagName === "H6") && this._isElementWithoutContent(node)) {
                node = this._removeAndGetNext(node);
                continue;
              }
              if (this.DEFAULT_TAGS_TO_SCORE.includes(node.tagName)) {
                elementsToScore.push(node);
              }
              if (node.tagName === "DIV") {
                var p = null;
                var childNode = node.firstChild;
                while (childNode) {
                  var nextSibling = childNode.nextSibling;
                  if (this._isPhrasingContent(childNode)) {
                    if (p !== null) {
                      p.appendChild(childNode);
                    } else if (!this._isWhitespace(childNode)) {
                      p = doc.createElement("p");
                      node.replaceChild(p, childNode);
                      p.appendChild(childNode);
                    }
                  } else if (p !== null) {
                    while (p.lastChild && this._isWhitespace(p.lastChild)) {
                      p.lastChild.remove();
                    }
                    p = null;
                  }
                  childNode = nextSibling;
                }
                if (this._hasSingleTagInsideElement(node, "P") && this._getLinkDensity(node) < 0.25) {
                  var newNode = node.children[0];
                  node.parentNode.replaceChild(newNode, node);
                  node = newNode;
                  elementsToScore.push(node);
                } else if (!this._hasChildBlockElement(node)) {
                  node = this._setNodeTag(node, "P");
                  elementsToScore.push(node);
                }
              }
              node = this._getNextNode(node);
            }
            var candidates = [];
            this._forEachNode(elementsToScore, function(elementToScore) {
              if (!elementToScore.parentNode || typeof elementToScore.parentNode.tagName === "undefined") {
                return;
              }
              var innerText = this._getInnerText(elementToScore);
              if (innerText.length < 25) {
                return;
              }
              var ancestors2 = this._getNodeAncestors(elementToScore, 5);
              if (ancestors2.length === 0) {
                return;
              }
              var contentScore = 0;
              contentScore += 1;
              contentScore += innerText.split(this.REGEXPS.commas).length;
              contentScore += Math.min(Math.floor(innerText.length / 100), 3);
              this._forEachNode(ancestors2, function(ancestor, level) {
                if (!ancestor.tagName || !ancestor.parentNode || typeof ancestor.parentNode.tagName === "undefined") {
                  return;
                }
                if (typeof ancestor.readability === "undefined") {
                  this._initializeNode(ancestor);
                  candidates.push(ancestor);
                }
                if (level === 0) {
                  var scoreDivider = 1;
                } else if (level === 1) {
                  scoreDivider = 2;
                } else {
                  scoreDivider = level * 3;
                }
                ancestor.readability.contentScore += contentScore / scoreDivider;
              });
            });
            var topCandidates = [];
            for (var c = 0, cl = candidates.length; c < cl; c += 1) {
              var candidate = candidates[c];
              var candidateScore = candidate.readability.contentScore * (1 - this._getLinkDensity(candidate));
              candidate.readability.contentScore = candidateScore;
              this.log("Candidate:", candidate, "with score " + candidateScore);
              for (var t = 0; t < this._nbTopCandidates; t++) {
                var aTopCandidate = topCandidates[t];
                if (!aTopCandidate || candidateScore > aTopCandidate.readability.contentScore) {
                  topCandidates.splice(t, 0, candidate);
                  if (topCandidates.length > this._nbTopCandidates) {
                    topCandidates.pop();
                  }
                  break;
                }
              }
            }
            var topCandidate = topCandidates[0] || null;
            var neededToCreateTopCandidate = false;
            var parentOfTopCandidate;
            if (topCandidate === null || topCandidate.tagName === "BODY") {
              topCandidate = doc.createElement("DIV");
              neededToCreateTopCandidate = true;
              while (page.firstChild) {
                this.log("Moving child out:", page.firstChild);
                topCandidate.appendChild(page.firstChild);
              }
              page.appendChild(topCandidate);
              this._initializeNode(topCandidate);
            } else if (topCandidate) {
              var alternativeCandidateAncestors = [];
              for (var i = 1; i < topCandidates.length; i++) {
                if (topCandidates[i].readability.contentScore / topCandidate.readability.contentScore >= 0.75) {
                  alternativeCandidateAncestors.push(
                    this._getNodeAncestors(topCandidates[i])
                  );
                }
              }
              var MINIMUM_TOPCANDIDATES = 3;
              if (alternativeCandidateAncestors.length >= MINIMUM_TOPCANDIDATES) {
                parentOfTopCandidate = topCandidate.parentNode;
                while (parentOfTopCandidate.tagName !== "BODY") {
                  var listsContainingThisAncestor = 0;
                  for (var ancestorIndex = 0; ancestorIndex < alternativeCandidateAncestors.length && listsContainingThisAncestor < MINIMUM_TOPCANDIDATES; ancestorIndex++) {
                    listsContainingThisAncestor += Number(
                      alternativeCandidateAncestors[ancestorIndex].includes(
                        parentOfTopCandidate
                      )
                    );
                  }
                  if (listsContainingThisAncestor >= MINIMUM_TOPCANDIDATES) {
                    topCandidate = parentOfTopCandidate;
                    break;
                  }
                  parentOfTopCandidate = parentOfTopCandidate.parentNode;
                }
              }
              if (!topCandidate.readability) {
                this._initializeNode(topCandidate);
              }
              parentOfTopCandidate = topCandidate.parentNode;
              var lastScore = topCandidate.readability.contentScore;
              var scoreThreshold = lastScore / 3;
              while (parentOfTopCandidate.tagName !== "BODY") {
                if (!parentOfTopCandidate.readability) {
                  parentOfTopCandidate = parentOfTopCandidate.parentNode;
                  continue;
                }
                var parentScore = parentOfTopCandidate.readability.contentScore;
                if (parentScore < scoreThreshold) {
                  break;
                }
                if (parentScore > lastScore) {
                  topCandidate = parentOfTopCandidate;
                  break;
                }
                lastScore = parentOfTopCandidate.readability.contentScore;
                parentOfTopCandidate = parentOfTopCandidate.parentNode;
              }
              parentOfTopCandidate = topCandidate.parentNode;
              while (parentOfTopCandidate.tagName != "BODY" && parentOfTopCandidate.children.length == 1) {
                topCandidate = parentOfTopCandidate;
                parentOfTopCandidate = topCandidate.parentNode;
              }
              if (!topCandidate.readability) {
                this._initializeNode(topCandidate);
              }
            }
            var articleContent = doc.createElement("DIV");
            if (isPaging) {
              articleContent.id = "readability-content";
            }
            var siblingScoreThreshold = Math.max(
              10,
              topCandidate.readability.contentScore * 0.2
            );
            parentOfTopCandidate = topCandidate.parentNode;
            var siblings = parentOfTopCandidate.children;
            for (var s = 0, sl = siblings.length; s < sl; s++) {
              var sibling = siblings[s];
              var append = false;
              this.log(
                "Looking at sibling node:",
                sibling,
                sibling.readability ? "with score " + sibling.readability.contentScore : ""
              );
              this.log(
                "Sibling has score",
                sibling.readability ? sibling.readability.contentScore : "Unknown"
              );
              if (sibling === topCandidate) {
                append = true;
              } else {
                var contentBonus = 0;
                if (sibling.className === topCandidate.className && topCandidate.className !== "") {
                  contentBonus += topCandidate.readability.contentScore * 0.2;
                }
                if (sibling.readability && sibling.readability.contentScore + contentBonus >= siblingScoreThreshold) {
                  append = true;
                } else if (sibling.nodeName === "P") {
                  var linkDensity = this._getLinkDensity(sibling);
                  var nodeContent = this._getInnerText(sibling);
                  var nodeLength = nodeContent.length;
                  if (nodeLength > 80 && linkDensity < 0.25) {
                    append = true;
                  } else if (nodeLength < 80 && nodeLength > 0 && linkDensity === 0 && nodeContent.search(/\.( |$)/) !== -1) {
                    append = true;
                  }
                }
              }
              if (append) {
                this.log("Appending node:", sibling);
                if (!this.ALTER_TO_DIV_EXCEPTIONS.includes(sibling.nodeName)) {
                  this.log("Altering sibling:", sibling, "to div.");
                  sibling = this._setNodeTag(sibling, "DIV");
                }
                articleContent.appendChild(sibling);
                siblings = parentOfTopCandidate.children;
                s -= 1;
                sl -= 1;
              }
            }
            if (this._debug) {
              this.log("Article content pre-prep: " + articleContent.innerHTML);
            }
            this._prepArticle(articleContent);
            if (this._debug) {
              this.log("Article content post-prep: " + articleContent.innerHTML);
            }
            if (neededToCreateTopCandidate) {
              topCandidate.id = "readability-page-1";
              topCandidate.className = "page";
            } else {
              var div = doc.createElement("DIV");
              div.id = "readability-page-1";
              div.className = "page";
              while (articleContent.firstChild) {
                div.appendChild(articleContent.firstChild);
              }
              articleContent.appendChild(div);
            }
            if (this._debug) {
              this.log("Article content after paging: " + articleContent.innerHTML);
            }
            var parseSuccessful = true;
            var textLength = this._getInnerText(articleContent, true).length;
            if (textLength < this._charThreshold) {
              parseSuccessful = false;
              page.innerHTML = pageCacheHtml;
              this._attempts.push({
                articleContent,
                textLength
              });
              if (this._flagIsActive(this.FLAG_STRIP_UNLIKELYS)) {
                this._removeFlag(this.FLAG_STRIP_UNLIKELYS);
              } else if (this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) {
                this._removeFlag(this.FLAG_WEIGHT_CLASSES);
              } else if (this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) {
                this._removeFlag(this.FLAG_CLEAN_CONDITIONALLY);
              } else {
                this._attempts.sort(function(a, b) {
                  return b.textLength - a.textLength;
                });
                if (!this._attempts[0].textLength) {
                  return null;
                }
                articleContent = this._attempts[0].articleContent;
                parseSuccessful = true;
              }
            }
            if (parseSuccessful) {
              var ancestors = [parentOfTopCandidate, topCandidate].concat(
                this._getNodeAncestors(parentOfTopCandidate)
              );
              this._someNode(ancestors, function(ancestor) {
                if (!ancestor.tagName) {
                  return false;
                }
                var articleDir = ancestor.getAttribute("dir");
                if (articleDir) {
                  this._articleDir = articleDir;
                  return true;
                }
                return false;
              });
              return articleContent;
            }
          }
        },
        /**
         * Converts some of the common HTML entities in string to their corresponding characters.
         *
         * @param str {string} - a string to unescape.
         * @return string without HTML entity.
         */
        _unescapeHtmlEntities(str) {
          if (!str) {
            return str;
          }
          var htmlEscapeMap = this.HTML_ESCAPE_MAP;
          return str.replace(/&(quot|amp|apos|lt|gt);/g, function(_, tag) {
            return htmlEscapeMap[tag];
          }).replace(/&#(?:x([0-9a-f]+)|([0-9]+));/gi, function(_, hex, numStr) {
            var num = parseInt(hex || numStr, hex ? 16 : 10);
            if (num == 0 || num > 1114111 || num >= 55296 && num <= 57343) {
              num = 65533;
            }
            return String.fromCodePoint(num);
          });
        },
        /**
         * Try to extract metadata from JSON-LD object.
         * For now, only Schema.org objects of type Article or its subtypes are supported.
         * @return Object with any metadata that could be extracted (possibly none)
         */
        _getJSONLD(doc) {
          var scripts = this._getAllNodesWithTag(doc, ["script"]);
          var metadata;
          this._forEachNode(scripts, function(jsonLdElement) {
            if (!metadata && jsonLdElement.getAttribute("type") === "application/ld+json") {
              try {
                var content = jsonLdElement.textContent.replace(
                  /^\s*<!\[CDATA\[|\]\]>\s*$/g,
                  ""
                );
                var parsed = JSON.parse(content);
                if (Array.isArray(parsed)) {
                  parsed = parsed.find((it) => {
                    return it["@type"] && it["@type"].match(this.REGEXPS.jsonLdArticleTypes);
                  });
                  if (!parsed) {
                    return;
                  }
                }
                var schemaDotOrgRegex = /^https?\:\/\/schema\.org\/?$/;
                var matches = typeof parsed["@context"] === "string" && parsed["@context"].match(schemaDotOrgRegex) || typeof parsed["@context"] === "object" && typeof parsed["@context"]["@vocab"] == "string" && parsed["@context"]["@vocab"].match(schemaDotOrgRegex);
                if (!matches) {
                  return;
                }
                if (!parsed["@type"] && Array.isArray(parsed["@graph"])) {
                  parsed = parsed["@graph"].find((it) => {
                    return (it["@type"] || "").match(this.REGEXPS.jsonLdArticleTypes);
                  });
                }
                if (!parsed || !parsed["@type"] || !parsed["@type"].match(this.REGEXPS.jsonLdArticleTypes)) {
                  return;
                }
                metadata = {};
                if (typeof parsed.name === "string" && typeof parsed.headline === "string" && parsed.name !== parsed.headline) {
                  var title = this._getArticleTitle();
                  var nameMatches = this._textSimilarity(parsed.name, title) > 0.75;
                  var headlineMatches = this._textSimilarity(parsed.headline, title) > 0.75;
                  if (headlineMatches && !nameMatches) {
                    metadata.title = parsed.headline;
                  } else {
                    metadata.title = parsed.name;
                  }
                } else if (typeof parsed.name === "string") {
                  metadata.title = parsed.name.trim();
                } else if (typeof parsed.headline === "string") {
                  metadata.title = parsed.headline.trim();
                }
                if (parsed.author) {
                  if (typeof parsed.author.name === "string") {
                    metadata.byline = parsed.author.name.trim();
                  } else if (Array.isArray(parsed.author) && parsed.author[0] && typeof parsed.author[0].name === "string") {
                    metadata.byline = parsed.author.filter(function(author) {
                      return author && typeof author.name === "string";
                    }).map(function(author) {
                      return author.name.trim();
                    }).join(", ");
                  }
                }
                if (typeof parsed.description === "string") {
                  metadata.excerpt = parsed.description.trim();
                }
                if (parsed.publisher && typeof parsed.publisher.name === "string") {
                  metadata.siteName = parsed.publisher.name.trim();
                }
                if (typeof parsed.datePublished === "string") {
                  metadata.datePublished = parsed.datePublished.trim();
                }
              } catch (err) {
                this.log(err.message);
              }
            }
          });
          return metadata ? metadata : {};
        },
        /**
         * Attempts to get excerpt and byline metadata for the article.
         *
         * @param {Object} jsonld — object containing any metadata that
         * could be extracted from JSON-LD object.
         *
         * @return Object with optional "excerpt" and "byline" properties
         */
        _getArticleMetadata(jsonld) {
          var metadata = {};
          var values = {};
          var metaElements = this._doc.getElementsByTagName("meta");
          var propertyPattern = /\s*(article|dc|dcterm|og|twitter)\s*:\s*(author|creator|description|published_time|title|site_name)\s*/gi;
          var namePattern = /^\s*(?:(dc|dcterm|og|twitter|parsely|weibo:(article|webpage))\s*[-\.:]\s*)?(author|creator|pub-date|description|title|site_name)\s*$/i;
          this._forEachNode(metaElements, function(element) {
            var elementName = element.getAttribute("name");
            var elementProperty = element.getAttribute("property");
            var content = element.getAttribute("content");
            if (!content) {
              return;
            }
            var matches = null;
            var name = null;
            if (elementProperty) {
              matches = elementProperty.match(propertyPattern);
              if (matches) {
                name = matches[0].toLowerCase().replace(/\s/g, "");
                values[name] = content.trim();
              }
            }
            if (!matches && elementName && namePattern.test(elementName)) {
              name = elementName;
              if (content) {
                name = name.toLowerCase().replace(/\s/g, "").replace(/\./g, ":");
                values[name] = content.trim();
              }
            }
          });
          metadata.title = jsonld.title || values["dc:title"] || values["dcterm:title"] || values["og:title"] || values["weibo:article:title"] || values["weibo:webpage:title"] || values.title || values["twitter:title"] || values["parsely-title"];
          if (!metadata.title) {
            metadata.title = this._getArticleTitle();
          }
          const articleAuthor = typeof values["article:author"] === "string" && !this._isUrl(values["article:author"]) ? values["article:author"] : void 0;
          metadata.byline = jsonld.byline || values["dc:creator"] || values["dcterm:creator"] || values.author || values["parsely-author"] || articleAuthor;
          metadata.excerpt = jsonld.excerpt || values["dc:description"] || values["dcterm:description"] || values["og:description"] || values["weibo:article:description"] || values["weibo:webpage:description"] || values.description || values["twitter:description"];
          metadata.siteName = jsonld.siteName || values["og:site_name"];
          metadata.publishedTime = jsonld.datePublished || values["article:published_time"] || values["parsely-pub-date"] || null;
          metadata.title = this._unescapeHtmlEntities(metadata.title);
          metadata.byline = this._unescapeHtmlEntities(metadata.byline);
          metadata.excerpt = this._unescapeHtmlEntities(metadata.excerpt);
          metadata.siteName = this._unescapeHtmlEntities(metadata.siteName);
          metadata.publishedTime = this._unescapeHtmlEntities(metadata.publishedTime);
          return metadata;
        },
        /**
         * Check if node is image, or if node contains exactly only one image
         * whether as a direct child or as its descendants.
         *
         * @param Element
         **/
        _isSingleImage(node) {
          while (node) {
            if (node.tagName === "IMG") {
              return true;
            }
            if (node.children.length !== 1 || node.textContent.trim() !== "") {
              return false;
            }
            node = node.children[0];
          }
          return false;
        },
        /**
         * Find all <noscript> that are located after <img> nodes, and which contain only one
         * <img> element. Replace the first image with the image from inside the <noscript> tag,
         * and remove the <noscript> tag. This improves the quality of the images we use on
         * some sites (e.g. Medium).
         *
         * @param Element
         **/
        _unwrapNoscriptImages(doc) {
          var imgs = Array.from(doc.getElementsByTagName("img"));
          this._forEachNode(imgs, function(img) {
            for (var i = 0; i < img.attributes.length; i++) {
              var attr = img.attributes[i];
              switch (attr.name) {
                case "src":
                case "srcset":
                case "data-src":
                case "data-srcset":
                  return;
              }
              if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                return;
              }
            }
            img.remove();
          });
          var noscripts = Array.from(doc.getElementsByTagName("noscript"));
          this._forEachNode(noscripts, function(noscript) {
            if (!this._isSingleImage(noscript)) {
              return;
            }
            var tmp = doc.createElement("div");
            tmp.innerHTML = noscript.innerHTML;
            var prevElement = noscript.previousElementSibling;
            if (prevElement && this._isSingleImage(prevElement)) {
              var prevImg = prevElement;
              if (prevImg.tagName !== "IMG") {
                prevImg = prevElement.getElementsByTagName("img")[0];
              }
              var newImg = tmp.getElementsByTagName("img")[0];
              for (var i = 0; i < prevImg.attributes.length; i++) {
                var attr = prevImg.attributes[i];
                if (attr.value === "") {
                  continue;
                }
                if (attr.name === "src" || attr.name === "srcset" || /\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                  if (newImg.getAttribute(attr.name) === attr.value) {
                    continue;
                  }
                  var attrName = attr.name;
                  if (newImg.hasAttribute(attrName)) {
                    attrName = "data-old-" + attrName;
                  }
                  newImg.setAttribute(attrName, attr.value);
                }
              }
              noscript.parentNode.replaceChild(tmp.firstElementChild, prevElement);
            }
          });
        },
        /**
         * Removes script tags from the document.
         *
         * @param Element
         **/
        _removeScripts(doc) {
          this._removeNodes(this._getAllNodesWithTag(doc, ["script", "noscript"]));
        },
        /**
         * Check if this node has only whitespace and a single element with given tag
         * Returns false if the DIV node contains non-empty text nodes
         * or if it contains no element with given tag or more than 1 element.
         *
         * @param Element
         * @param string tag of child element
         **/
        _hasSingleTagInsideElement(element, tag) {
          if (element.children.length != 1 || element.children[0].tagName !== tag) {
            return false;
          }
          return !this._someNode(element.childNodes, function(node) {
            return node.nodeType === this.TEXT_NODE && this.REGEXPS.hasContent.test(node.textContent);
          });
        },
        _isElementWithoutContent(node) {
          return node.nodeType === this.ELEMENT_NODE && !node.textContent.trim().length && (!node.children.length || node.children.length == node.getElementsByTagName("br").length + node.getElementsByTagName("hr").length);
        },
        /**
         * Determine whether element has any children block level elements.
         *
         * @param Element
         */
        _hasChildBlockElement(element) {
          return this._someNode(element.childNodes, function(node) {
            return this.DIV_TO_P_ELEMS.has(node.tagName) || this._hasChildBlockElement(node);
          });
        },
        /***
         * Determine if a node qualifies as phrasing content.
         * https://developer.mozilla.org/en-US/docs/Web/Guide/HTML/Content_categories#Phrasing_content
         **/
        _isPhrasingContent(node) {
          return node.nodeType === this.TEXT_NODE || this.PHRASING_ELEMS.includes(node.tagName) || (node.tagName === "A" || node.tagName === "DEL" || node.tagName === "INS") && this._everyNode(node.childNodes, this._isPhrasingContent);
        },
        _isWhitespace(node) {
          return node.nodeType === this.TEXT_NODE && node.textContent.trim().length === 0 || node.nodeType === this.ELEMENT_NODE && node.tagName === "BR";
        },
        /**
         * Get the inner text of a node - cross browser compatibly.
         * This also strips out any excess whitespace to be found.
         *
         * @param Element
         * @param Boolean normalizeSpaces (default: true)
         * @return string
         **/
        _getInnerText(e, normalizeSpaces) {
          normalizeSpaces = typeof normalizeSpaces === "undefined" ? true : normalizeSpaces;
          var textContent = e.textContent.trim();
          if (normalizeSpaces) {
            return textContent.replace(this.REGEXPS.normalize, " ");
          }
          return textContent;
        },
        /**
         * Get the number of times a string s appears in the node e.
         *
         * @param Element
         * @param string - what to split on. Default is ","
         * @return number (integer)
         **/
        _getCharCount(e, s) {
          s = s || ",";
          return this._getInnerText(e).split(s).length - 1;
        },
        /**
         * Remove the style attribute on every e and under.
         * TODO: Test if getElementsByTagName(*) is faster.
         *
         * @param Element
         * @return void
         **/
        _cleanStyles(e) {
          if (!e || e.tagName.toLowerCase() === "svg") {
            return;
          }
          for (var i = 0; i < this.PRESENTATIONAL_ATTRIBUTES.length; i++) {
            e.removeAttribute(this.PRESENTATIONAL_ATTRIBUTES[i]);
          }
          if (this.DEPRECATED_SIZE_ATTRIBUTE_ELEMS.includes(e.tagName)) {
            e.removeAttribute("width");
            e.removeAttribute("height");
          }
          var cur = e.firstElementChild;
          while (cur !== null) {
            this._cleanStyles(cur);
            cur = cur.nextElementSibling;
          }
        },
        /**
         * Get the density of links as a percentage of the content
         * This is the amount of text that is inside a link divided by the total text in the node.
         *
         * @param Element
         * @return number (float)
         **/
        _getLinkDensity(element) {
          var textLength = this._getInnerText(element).length;
          if (textLength === 0) {
            return 0;
          }
          var linkLength = 0;
          this._forEachNode(element.getElementsByTagName("a"), function(linkNode) {
            var href = linkNode.getAttribute("href");
            var coefficient = href && this.REGEXPS.hashUrl.test(href) ? 0.3 : 1;
            linkLength += this._getInnerText(linkNode).length * coefficient;
          });
          return linkLength / textLength;
        },
        /**
         * Get an elements class/id weight. Uses regular expressions to tell if this
         * element looks good or bad.
         *
         * @param Element
         * @return number (Integer)
         **/
        _getClassWeight(e) {
          if (!this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) {
            return 0;
          }
          var weight = 0;
          if (typeof e.className === "string" && e.className !== "") {
            if (this.REGEXPS.negative.test(e.className)) {
              weight -= 25;
            }
            if (this.REGEXPS.positive.test(e.className)) {
              weight += 25;
            }
          }
          if (typeof e.id === "string" && e.id !== "") {
            if (this.REGEXPS.negative.test(e.id)) {
              weight -= 25;
            }
            if (this.REGEXPS.positive.test(e.id)) {
              weight += 25;
            }
          }
          return weight;
        },
        /**
         * Clean a node of all elements of type "tag".
         * (Unless it's a youtube/vimeo video. People love movies.)
         *
         * @param Element
         * @param string tag to clean
         * @return void
         **/
        _clean(e, tag) {
          var isEmbed = ["object", "embed", "iframe"].includes(tag);
          this._removeNodes(this._getAllNodesWithTag(e, [tag]), function(element) {
            if (isEmbed) {
              for (var i = 0; i < element.attributes.length; i++) {
                if (this._allowedVideoRegex.test(element.attributes[i].value)) {
                  return false;
                }
              }
              if (element.tagName === "object" && this._allowedVideoRegex.test(element.innerHTML)) {
                return false;
              }
            }
            return true;
          });
        },
        /**
         * Check if a given node has one of its ancestor tag name matching the
         * provided one.
         * @param  HTMLElement node
         * @param  String      tagName
         * @param  Number      maxDepth
         * @param  Function    filterFn a filter to invoke to determine whether this node 'counts'
         * @return Boolean
         */
        _hasAncestorTag(node, tagName, maxDepth, filterFn) {
          maxDepth = maxDepth || 3;
          tagName = tagName.toUpperCase();
          var depth = 0;
          while (node.parentNode) {
            if (maxDepth > 0 && depth > maxDepth) {
              return false;
            }
            if (node.parentNode.tagName === tagName && (!filterFn || filterFn(node.parentNode))) {
              return true;
            }
            node = node.parentNode;
            depth++;
          }
          return false;
        },
        /**
         * Return an object indicating how many rows and columns this table has.
         */
        _getRowAndColumnCount(table) {
          var rows = 0;
          var columns = 0;
          var trs = table.getElementsByTagName("tr");
          for (var i = 0; i < trs.length; i++) {
            var rowspan = trs[i].getAttribute("rowspan") || 0;
            if (rowspan) {
              rowspan = parseInt(rowspan, 10);
            }
            rows += rowspan || 1;
            var columnsInThisRow = 0;
            var cells = trs[i].getElementsByTagName("td");
            for (var j = 0; j < cells.length; j++) {
              var colspan = cells[j].getAttribute("colspan") || 0;
              if (colspan) {
                colspan = parseInt(colspan, 10);
              }
              columnsInThisRow += colspan || 1;
            }
            columns = Math.max(columns, columnsInThisRow);
          }
          return { rows, columns };
        },
        /**
         * Look for 'data' (as opposed to 'layout') tables, for which we use
         * similar checks as
         * https://searchfox.org/mozilla-central/rev/f82d5c549f046cb64ce5602bfd894b7ae807c8f8/accessible/generic/TableAccessible.cpp#19
         */
        _markDataTables(root) {
          var tables = root.getElementsByTagName("table");
          for (var i = 0; i < tables.length; i++) {
            var table = tables[i];
            var role = table.getAttribute("role");
            if (role == "presentation") {
              table._readabilityDataTable = false;
              continue;
            }
            var datatable = table.getAttribute("datatable");
            if (datatable == "0") {
              table._readabilityDataTable = false;
              continue;
            }
            var summary = table.getAttribute("summary");
            if (summary) {
              table._readabilityDataTable = true;
              continue;
            }
            var caption = table.getElementsByTagName("caption")[0];
            if (caption && caption.childNodes.length) {
              table._readabilityDataTable = true;
              continue;
            }
            var dataTableDescendants = ["col", "colgroup", "tfoot", "thead", "th"];
            var descendantExists = function(tag) {
              return !!table.getElementsByTagName(tag)[0];
            };
            if (dataTableDescendants.some(descendantExists)) {
              this.log("Data table because found data-y descendant");
              table._readabilityDataTable = true;
              continue;
            }
            if (table.getElementsByTagName("table")[0]) {
              table._readabilityDataTable = false;
              continue;
            }
            var sizeInfo = this._getRowAndColumnCount(table);
            if (sizeInfo.columns == 1 || sizeInfo.rows == 1) {
              table._readabilityDataTable = false;
              continue;
            }
            if (sizeInfo.rows >= 10 || sizeInfo.columns > 4) {
              table._readabilityDataTable = true;
              continue;
            }
            table._readabilityDataTable = sizeInfo.rows * sizeInfo.columns > 10;
          }
        },
        /* convert images and figures that have properties like data-src into images that can be loaded without JS */
        _fixLazyImages(root) {
          this._forEachNode(
            this._getAllNodesWithTag(root, ["img", "picture", "figure"]),
            function(elem) {
              if (elem.src && this.REGEXPS.b64DataUrl.test(elem.src)) {
                var parts = this.REGEXPS.b64DataUrl.exec(elem.src);
                if (parts[1] === "image/svg+xml") {
                  return;
                }
                var srcCouldBeRemoved = false;
                for (var i = 0; i < elem.attributes.length; i++) {
                  var attr = elem.attributes[i];
                  if (attr.name === "src") {
                    continue;
                  }
                  if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                    srcCouldBeRemoved = true;
                    break;
                  }
                }
                if (srcCouldBeRemoved) {
                  var b64starts = parts[0].length;
                  var b64length = elem.src.length - b64starts;
                  if (b64length < 133) {
                    elem.removeAttribute("src");
                  }
                }
              }
              if ((elem.src || elem.srcset && elem.srcset != "null") && !elem.className.toLowerCase().includes("lazy")) {
                return;
              }
              for (var j = 0; j < elem.attributes.length; j++) {
                attr = elem.attributes[j];
                if (attr.name === "src" || attr.name === "srcset" || attr.name === "alt") {
                  continue;
                }
                var copyTo = null;
                if (/\.(jpg|jpeg|png|webp)\s+\d/.test(attr.value)) {
                  copyTo = "srcset";
                } else if (/^\s*\S+\.(jpg|jpeg|png|webp)\S*\s*$/.test(attr.value)) {
                  copyTo = "src";
                }
                if (copyTo) {
                  if (elem.tagName === "IMG" || elem.tagName === "PICTURE") {
                    elem.setAttribute(copyTo, attr.value);
                  } else if (elem.tagName === "FIGURE" && !this._getAllNodesWithTag(elem, ["img", "picture"]).length) {
                    var img = this._doc.createElement("img");
                    img.setAttribute(copyTo, attr.value);
                    elem.appendChild(img);
                  }
                }
              }
            }
          );
        },
        _getTextDensity(e, tags) {
          var textLength = this._getInnerText(e, true).length;
          if (textLength === 0) {
            return 0;
          }
          var childrenLength = 0;
          var children = this._getAllNodesWithTag(e, tags);
          this._forEachNode(
            children,
            (child) => childrenLength += this._getInnerText(child, true).length
          );
          return childrenLength / textLength;
        },
        /**
         * Clean an element of all tags of type "tag" if they look fishy.
         * "Fishy" is an algorithm based on content length, classnames, link density, number of images & embeds, etc.
         *
         * @return void
         **/
        _cleanConditionally(e, tag) {
          if (!this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) {
            return;
          }
          this._removeNodes(this._getAllNodesWithTag(e, [tag]), function(node) {
            var isDataTable = function(t) {
              return t._readabilityDataTable;
            };
            var isList = tag === "ul" || tag === "ol";
            if (!isList) {
              var listLength = 0;
              var listNodes = this._getAllNodesWithTag(node, ["ul", "ol"]);
              this._forEachNode(
                listNodes,
                (list) => listLength += this._getInnerText(list).length
              );
              isList = listLength / this._getInnerText(node).length > 0.9;
            }
            if (tag === "table" && isDataTable(node)) {
              return false;
            }
            if (this._hasAncestorTag(node, "table", -1, isDataTable)) {
              return false;
            }
            if (this._hasAncestorTag(node, "code")) {
              return false;
            }
            if ([...node.getElementsByTagName("table")].some(
              (tbl) => tbl._readabilityDataTable
            )) {
              return false;
            }
            var weight = this._getClassWeight(node);
            this.log("Cleaning Conditionally", node);
            var contentScore = 0;
            if (weight + contentScore < 0) {
              return true;
            }
            if (this._getCharCount(node, ",") < 10) {
              var p = node.getElementsByTagName("p").length;
              var img = node.getElementsByTagName("img").length;
              var li = node.getElementsByTagName("li").length - 100;
              var input = node.getElementsByTagName("input").length;
              var headingDensity = this._getTextDensity(node, [
                "h1",
                "h2",
                "h3",
                "h4",
                "h5",
                "h6"
              ]);
              var embedCount = 0;
              var embeds = this._getAllNodesWithTag(node, [
                "object",
                "embed",
                "iframe"
              ]);
              for (var i = 0; i < embeds.length; i++) {
                for (var j = 0; j < embeds[i].attributes.length; j++) {
                  if (this._allowedVideoRegex.test(embeds[i].attributes[j].value)) {
                    return false;
                  }
                }
                if (embeds[i].tagName === "object" && this._allowedVideoRegex.test(embeds[i].innerHTML)) {
                  return false;
                }
                embedCount++;
              }
              var innerText = this._getInnerText(node);
              if (this.REGEXPS.adWords.test(innerText) || this.REGEXPS.loadingWords.test(innerText)) {
                return true;
              }
              var contentLength = innerText.length;
              var linkDensity = this._getLinkDensity(node);
              var textishTags = ["SPAN", "LI", "TD"].concat(
                Array.from(this.DIV_TO_P_ELEMS)
              );
              var textDensity = this._getTextDensity(node, textishTags);
              var isFigureChild = this._hasAncestorTag(node, "figure");
              const shouldRemoveNode = () => {
                const errs = [];
                if (!isFigureChild && img > 1 && p / img < 0.5) {
                  errs.push(`Bad p to img ratio (img=${img}, p=${p})`);
                }
                if (!isList && li > p) {
                  errs.push(`Too many li's outside of a list. (li=${li} > p=${p})`);
                }
                if (input > Math.floor(p / 3)) {
                  errs.push(`Too many inputs per p. (input=${input}, p=${p})`);
                }
                if (!isList && !isFigureChild && headingDensity < 0.9 && contentLength < 25 && (img === 0 || img > 2) && linkDensity > 0) {
                  errs.push(
                    `Suspiciously short. (headingDensity=${headingDensity}, img=${img}, linkDensity=${linkDensity})`
                  );
                }
                if (!isList && weight < 25 && linkDensity > 0.2 + this._linkDensityModifier) {
                  errs.push(
                    `Low weight and a little linky. (linkDensity=${linkDensity})`
                  );
                }
                if (weight >= 25 && linkDensity > 0.5 + this._linkDensityModifier) {
                  errs.push(
                    `High weight and mostly links. (linkDensity=${linkDensity})`
                  );
                }
                if (embedCount === 1 && contentLength < 75 || embedCount > 1) {
                  errs.push(
                    `Suspicious embed. (embedCount=${embedCount}, contentLength=${contentLength})`
                  );
                }
                if (img === 0 && textDensity === 0) {
                  errs.push(
                    `No useful content. (img=${img}, textDensity=${textDensity})`
                  );
                }
                if (errs.length) {
                  this.log("Checks failed", errs);
                  return true;
                }
                return false;
              };
              var haveToRemove = shouldRemoveNode();
              if (isList && haveToRemove) {
                for (var x = 0; x < node.children.length; x++) {
                  let child = node.children[x];
                  if (child.children.length > 1) {
                    return haveToRemove;
                  }
                }
                let li_count = node.getElementsByTagName("li").length;
                if (img == li_count) {
                  return false;
                }
              }
              return haveToRemove;
            }
            return false;
          });
        },
        /**
         * Clean out elements that match the specified conditions
         *
         * @param Element
         * @param Function determines whether a node should be removed
         * @return void
         **/
        _cleanMatchedNodes(e, filter) {
          var endOfSearchMarkerNode = this._getNextNode(e, true);
          var next = this._getNextNode(e);
          while (next && next != endOfSearchMarkerNode) {
            if (filter.call(this, next, next.className + " " + next.id)) {
              next = this._removeAndGetNext(next);
            } else {
              next = this._getNextNode(next);
            }
          }
        },
        /**
         * Clean out spurious headers from an Element.
         *
         * @param Element
         * @return void
         **/
        _cleanHeaders(e) {
          let headingNodes = this._getAllNodesWithTag(e, ["h1", "h2"]);
          this._removeNodes(headingNodes, function(node) {
            let shouldRemove = this._getClassWeight(node) < 0;
            if (shouldRemove) {
              this.log("Removing header with low class weight:", node);
            }
            return shouldRemove;
          });
        },
        /**
         * Check if this node is an H1 or H2 element whose content is mostly
         * the same as the article title.
         *
         * @param Element  the node to check.
         * @return boolean indicating whether this is a title-like header.
         */
        _headerDuplicatesTitle(node) {
          if (node.tagName != "H1" && node.tagName != "H2") {
            return false;
          }
          var heading = this._getInnerText(node, false);
          this.log("Evaluating similarity of header:", heading, this._articleTitle);
          return this._textSimilarity(this._articleTitle, heading) > 0.75;
        },
        _flagIsActive(flag) {
          return (this._flags & flag) > 0;
        },
        _removeFlag(flag) {
          this._flags = this._flags & ~flag;
        },
        _isProbablyVisible(node) {
          return (!node.style || node.style.display != "none") && (!node.style || node.style.visibility != "hidden") && !node.hasAttribute("hidden") && //check for "fallback-image" so that wikimedia math images are displayed
          (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.includes && node.className.includes("fallback-image"));
        },
        /**
         * Runs readability.
         *
         * Workflow:
         *  1. Prep the document by removing script tags, css, etc.
         *  2. Build readability's DOM tree.
         *  3. Grab the article content from the current dom tree.
         *  4. Replace the current DOM tree with the new one.
         *  5. Read peacefully.
         *
         * @return void
         **/
        parse() {
          if (this._maxElemsToParse > 0) {
            var numTags = this._doc.getElementsByTagName("*").length;
            if (numTags > this._maxElemsToParse) {
              throw new Error(
                "Aborting parsing document; " + numTags + " elements found"
              );
            }
          }
          this._unwrapNoscriptImages(this._doc);
          var jsonLd = this._disableJSONLD ? {} : this._getJSONLD(this._doc);
          this._removeScripts(this._doc);
          this._prepDocument();
          var metadata = this._getArticleMetadata(jsonLd);
          this._metadata = metadata;
          this._articleTitle = metadata.title;
          var articleContent = this._grabArticle();
          if (!articleContent) {
            return null;
          }
          this.log("Grabbed: " + articleContent.innerHTML);
          this._postProcessContent(articleContent);
          if (!metadata.excerpt) {
            var paragraphs = articleContent.getElementsByTagName("p");
            if (paragraphs.length) {
              metadata.excerpt = paragraphs[0].textContent.trim();
            }
          }
          var textContent = articleContent.textContent;
          return {
            title: this._articleTitle,
            byline: metadata.byline || this._articleByline,
            dir: this._articleDir,
            lang: this._articleLang,
            content: this._serializer(articleContent),
            textContent,
            length: textContent.length,
            excerpt: metadata.excerpt,
            siteName: metadata.siteName || this._articleSiteName,
            publishedTime: metadata.publishedTime
          };
        }
      };
      if (typeof module === "object") {
        module.exports = Readability2;
      }
    }
  });

  // node_modules/@mozilla/readability/Readability-readerable.js
  var require_Readability_readerable = __commonJS({
    "node_modules/@mozilla/readability/Readability-readerable.js"(exports, module) {
      var REGEXPS = {
        // NOTE: These two regular expressions are duplicated in
        // Readability.js. Please keep both copies in sync.
        unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
        okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i
      };
      function isNodeVisible(node) {
        return (!node.style || node.style.display != "none") && !node.hasAttribute("hidden") && //check for "fallback-image" so that wikimedia math images are displayed
        (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.includes && node.className.includes("fallback-image"));
      }
      function isProbablyReaderable2(doc, options = {}) {
        if (typeof options == "function") {
          options = { visibilityChecker: options };
        }
        var defaultOptions = {
          minScore: 20,
          minContentLength: 140,
          visibilityChecker: isNodeVisible
        };
        options = Object.assign(defaultOptions, options);
        var nodes = doc.querySelectorAll("p, pre, article");
        var brNodes = doc.querySelectorAll("div > br");
        if (brNodes.length) {
          var set = new Set(nodes);
          [].forEach.call(brNodes, function(node) {
            set.add(node.parentNode);
          });
          nodes = Array.from(set);
        }
        var score = 0;
        return [].some.call(nodes, function(node) {
          if (!options.visibilityChecker(node)) {
            return false;
          }
          var matchString = node.className + " " + node.id;
          if (REGEXPS.unlikelyCandidates.test(matchString) && !REGEXPS.okMaybeItsACandidate.test(matchString)) {
            return false;
          }
          if (node.matches("li p")) {
            return false;
          }
          var textContentLength = node.textContent.trim().length;
          if (textContentLength < options.minContentLength) {
            return false;
          }
          score += Math.sqrt(textContentLength - options.minContentLength);
          if (score > options.minScore) {
            return true;
          }
          return false;
        });
      }
      if (typeof module === "object") {
        module.exports = isProbablyReaderable2;
      }
    }
  });

  // node_modules/@mozilla/readability/index.js
  var require_readability = __commonJS({
    "node_modules/@mozilla/readability/index.js"(exports, module) {
      var Readability2 = require_Readability();
      var isProbablyReaderable2 = require_Readability_readerable();
      module.exports = {
        Readability: Readability2,
        isProbablyReaderable: isProbablyReaderable2
      };
    }
  });

  // src/content/extract.ts
  var import_readability = __toESM(require_readability(), 1);

  // src/content/canonical-url.ts
  function isLocalHost(hostname) {
    const host = hostname.toLowerCase().replace(/^\[|\]$/g, "").replace(/\.$/, "");
    return host === "localhost" || host.endsWith(".localhost") || host === "::1" || host === "0.0.0.0" || /^127(?:\.\d{1,3}){3}$/.test(host);
  }
  function canonicalContentUrl(canonical, pageUrl) {
    try {
      const page = new URL(pageUrl);
      page.hash = "";
      if (!canonical) return page.href;
      const target = new URL(canonical, page);
      if (isLocalHost(target.hostname) && !isLocalHost(page.hostname)) return page.href;
      target.hash = "";
      return target.href;
    } catch {
      return pageUrl.split("#")[0];
    }
  }

  // src/content/extract.ts
  function metaContent(names) {
    for (const name of names) {
      const el = document.querySelector(`meta[property="${name}"]`) || document.querySelector(`meta[name="${name}"]`);
      const content = el?.getAttribute("content")?.trim();
      if (content) return content;
    }
    return "";
  }
  function authorFromPage() {
    return metaContent(["article:author", "author", "twitter:creator"]) || document.querySelector('[rel="author"]')?.textContent?.trim() || document.querySelector('[itemprop="author"]')?.textContent?.trim() || "";
  }
  function fingerprint(text) {
    let h = 2166136261;
    const norm = text.toLowerCase().replace(/\s+/g, " ").slice(0, 8e3);
    for (let i = 0; i < norm.length; i++) {
      h ^= norm.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return ("0000000" + (h >>> 0).toString(16)).slice(-8);
  }
  function isWalletAddress(value) {
    return /^0x[a-fA-F0-9]{40}$/.test((value || "").trim());
  }
  function recipientWalletFromPage(root = document) {
    const found = recipientWalletsFromPage(root);
    return found.length ? found[0].address : "";
  }
  function recipientWalletsFromPage(root = document) {
    const doc = root;
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    const push = (address, context) => {
      const clean = (address || "").trim();
      if (!isWalletAddress(clean)) return;
      const key = clean.toLowerCase();
      if (seen.has(key)) return;
      seen.add(key);
      out.push({ address: clean, context: String(context || "").replace(/\s+/g, " ").trim().slice(0, 300) });
    };
    const meta = ["nibgate:recipient", "nibgate:wallet", "nibgate:tip-to"];
    for (const name of meta) {
      const el = doc.querySelector?.(`meta[property="${name}"],meta[name="${name}"]`);
      push(el?.getAttribute?.("content") || "", "page metadata: declared tip recipient");
    }
    const paymentLinks = Array.from(doc.querySelectorAll?.('link[rel="payment"],a[rel="payment"]') || []);
    for (const el of paymentLinks.slice(0, 4)) {
      const href = el.getAttribute?.("href") || "";
      const ethMatch = href.match(/ethereum:(0x[a-fA-F0-9]{40})/i);
      if (ethMatch) push(ethMatch[1], `payment link: ${el.textContent || href}`.slice(0, 300));
    }
    const tagged = doc.querySelector?.("[data-nibgate-recipient]");
    push(tagged?.getAttribute?.("data-nibgate-recipient") || "", "tagged recipient slot on the page");
    const authorZones = Array.from(
      doc.querySelectorAll?.('[rel="author"],[itemprop="author"],.byline,.author,.post-author,.entry-author,address') || []
    );
    const addrRe = /0x[a-fA-F0-9]{40}/g;
    for (const zone of authorZones.slice(0, 6)) {
      const text = zone.textContent || "";
      let m;
      while ((m = addrRe.exec(text)) !== null && out.length < 8) {
        push(m[0], `near author credit: ${text.slice(Math.max(0, m.index - 80), m.index + 120)}`);
      }
      if (out.length >= 8) break;
    }
    return out.slice(0, 8);
  }
  function hasNibgateSdk(root = document) {
    const doc = root;
    if (doc.querySelector?.('script[src*="widget.js"][src*="nibgate"]')) return true;
    if (doc.querySelector?.("[data-nibgate-site],[data-nibgate-resource]")) return true;
    return false;
  }
  var BOILERPLATE_SELECTORS = 'header, nav, footer, aside, form, dialog, [role="navigation"], [role="complementary"], [role="contentinfo"], [aria-hidden="true"], .comments, .comment, #comments, .sidebar, .widget, .related, .webring, .footer';
  var UNLIKELY_CANDIDATE_PATTERN = /combx|comment|community|disqus|extra|foot|header|menu|remark|rss|shoutbox|sidebar|sponsor|ad-break|agegate|pagination|pager|popup|tweet|twitter|widget|related|footer/i;
  var LIKELY_CANDIDATE_PATTERN = /and|article|body|column|content|main|post|text|blog|story|shadow/i;
  function hasBoilerplateName(start) {
    const haystack = `${start.id || ""} ${start.getAttribute("class") || ""}`.trim();
    if (haystack.length < 2) return false;
    return UNLIKELY_CANDIDATE_PATTERN.test(haystack) && !LIKELY_CANDIDATE_PATTERN.test(haystack);
  }
  function isBoilerplateZone(start) {
    if (!start) return false;
    if (hasBoilerplateName(start)) return true;
    return Boolean(start.closest(BOILERPLATE_SELECTORS));
  }
  function proseLength(element) {
    let score = 0;
    element.querySelectorAll("p, blockquote, li").forEach((paragraph) => {
      if (isBoilerplateZone(paragraph)) return;
      score += Math.min((paragraph.textContent || "").trim().length, 2e3);
    });
    return score;
  }
  function contentContainer(root = document) {
    const doc = root;
    const candidates = Array.from(
      doc.querySelectorAll?.('article, main, [role="main"], section, div') ?? []
    );
    const depthOf = (el) => {
      let d = 0;
      let n = el;
      while (n?.parentElement) {
        d++;
        n = n.parentElement;
      }
      return d;
    };
    let best = null;
    let bestScore = -1;
    let bestDepth = -1;
    for (const el of candidates) {
      if (isBoilerplateZone(el)) continue;
      const paras = el.querySelectorAll("p, blockquote, li");
      const isContentTag = el.tagName === "ARTICLE" || el.tagName === "MAIN" || el.getAttribute("role") === "main";
      if (paras.length < 2 && !isContentTag) continue;
      const score = proseLength(el);
      const depth = depthOf(el);
      if (score > bestScore || score === bestScore && depth > bestDepth) {
        best = el;
        bestScore = score;
        bestDepth = depth;
      }
    }
    return best || doc.body || document.body;
  }
  function extractContent() {
    let readerable = false;
    try {
      readerable = (0, import_readability.isProbablyReaderable)(document, { minContentLength: 240, minScore: 24 });
    } catch {
      return null;
    }
    if (!readerable) return null;
    let parsed = null;
    try {
      parsed = new import_readability.Readability(document.cloneNode(true)).parse();
    } catch {
      return null;
    }
    if (!parsed || !parsed.textContent || (parsed.length ?? 0) < 200) return null;
    const canonical = document.querySelector('link[rel="canonical"]')?.getAttribute("href") || window.location.href.split("#")[0];
    const text = parsed.textContent.trim();
    const words = text.split(/\s+/).filter(Boolean);
    return {
      url: window.location.href.split("#")[0],
      canonicalUrl: canonicalContentUrl(canonical, window.location.href),
      title: parsed.title || metaContent(["og:title", "twitter:title"]) || document.title || "Untitled",
      author: parsed.byline || authorFromPage(),
      siteName: parsed.siteName || metaContent(["og:site_name"]) || window.location.hostname.replace(/^www\./, ""),
      fingerprint: fingerprint((parsed.title || "") + "\n" + text),
      wordCount: words.length,
      // Last words of the canonical reader text. These anchor the live
      // placement marker to the real ending, not a visually similar sidebar,
      // code block, or footer.
      excerptTail: words.slice(-120).join(" ")
    };
  }

  // ../jev/src/decide.ts
  function optionValue(option, policy) {
    const penalty = policy.costPenalty ?? 1;
    let value = 0;
    for (const [signal, weight] of Object.entries(policy.weights)) {
      const score = option.scores[signal] ?? 0;
      value += weight * Math.min(1, Math.max(0, score));
    }
    return value - penalty * Math.max(0, option.cost);
  }
  function reasonsFor(option, policy, value) {
    const penalty = policy.costPenalty ?? 1;
    const parts = Object.entries(policy.weights).map(([signal, weight]) => {
      const score = option.scores[signal] ?? 0;
      return { signal, contribution: weight * score, score };
    }).filter((p) => p.contribution !== 0).sort((a, b) => b.contribution - a.contribution).slice(0, 3).map((p) => `${p.signal} ${p.score.toFixed(2)} (weight ${policy.weights[p.signal]})`);
    const out = [`value ${value.toFixed(3)} vs cost ${option.cost}`];
    if (parts.length) out.push(...parts);
    return out;
  }
  function selectMany(options, policy, maxPicks = Infinity) {
    const cap = policy.maxCost ?? policy.budgetRemaining;
    const minConfidence = policy.minConfidence ?? 0;
    const slate = { picks: [], skipped: [], escalated: [], budgetAfter: policy.budgetRemaining };
    const ranked = options.map((o) => ({ o, value: optionValue(o, policy) })).sort((a, b) => b.value - a.value || (a.o.id < b.o.id ? -1 : 1));
    for (const { o, value } of ranked) {
      if (slate.picks.length >= maxPicks) {
        slate.skipped.push({ option: o, reason: "beyond max picks" });
        continue;
      }
      if (o.cost < 0 || o.cost > Math.min(cap, slate.budgetAfter)) {
        slate.skipped.push({ option: o, reason: `unaffordable (cost ${o.cost}, remaining ${slate.budgetAfter})` });
        continue;
      }
      const confidence = o.scores["confidence"] ?? 1;
      if (confidence < minConfidence) {
        slate.escalated.push({ option: o, reason: `confidence ${confidence.toFixed(2)} below ${minConfidence}` });
        continue;
      }
      if (value <= 0) {
        slate.skipped.push({ option: o, reason: `value ${value.toFixed(3)} not worth it` });
        continue;
      }
      slate.budgetAfter -= o.cost;
      slate.picks.push({ option: o, value, reasons: reasonsFor(o, policy, value), budgetAfter: slate.budgetAfter });
    }
    return slate;
  }
  function decide(options, policy) {
    const cap = policy.maxCost ?? policy.budgetRemaining;
    const minConfidence = policy.minConfidence ?? 0;
    const eligible = options.filter((o) => o.cost >= 0 && o.cost <= Math.min(cap, policy.budgetRemaining));
    if (!eligible.length) {
      return {
        kind: "skip_all",
        optionId: null,
        action: "skip",
        value: 0,
        reasons: ["no affordable options within budget"],
        budgetAfter: policy.budgetRemaining,
        escalated: false
      };
    }
    const ranked = eligible.map((o) => ({ o, value: optionValue(o, policy) })).sort((a, b) => b.value - a.value || (a.o.id < b.o.id ? -1 : 1));
    const winner = ranked[0];
    const confidence = winner.o.scores["confidence"] ?? 1;
    if (confidence < minConfidence) {
      return {
        kind: "escalate",
        optionId: winner.o.id,
        action: "escalate",
        value: winner.value,
        reasons: [`confidence ${confidence.toFixed(2)} below threshold ${minConfidence} \u2014 human decides`],
        budgetAfter: policy.budgetRemaining,
        escalated: true
      };
    }
    if (winner.value <= 0) {
      return {
        kind: "skip_all",
        optionId: null,
        action: "skip",
        value: 0,
        reasons: [`best option value ${winner.value.toFixed(3)} not worth it`],
        budgetAfter: policy.budgetRemaining,
        escalated: false
      };
    }
    return {
      kind: "select",
      optionId: winner.o.id,
      action: winner.o.kind,
      value: winner.value,
      reasons: reasonsFor(winner.o, policy, winner.value),
      budgetAfter: policy.budgetRemaining - winner.o.cost,
      escalated: false
    };
  }

  // ../jev/src/trace.ts
  function renderTrace(decision, options, policy) {
    const lines = ["DECISION"];
    const byId = new Map(options.map((o) => [o.id, o]));
    if (decision.kind === "select" && decision.optionId) {
      const o = byId.get(decision.optionId);
      lines.push(`Action \u2192 ${decision.action.toUpperCase()} (${decision.optionId})`);
      if (o) {
        lines.push(`Cost: ${o.cost}`);
        const scored = Object.entries(o.scores).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} ${Number(v).toFixed(2)}`).join(" \xB7 ");
        if (scored) lines.push(`Signals: ${scored}`);
      }
      lines.push(`Budget: ${policy.budgetRemaining} \u2192 ${decision.budgetAfter}`);
    } else if (decision.kind === "escalate") {
      lines.push(`Action \u2192 ESCALATE${decision.optionId ? ` (${decision.optionId})` : ""}`);
      lines.push(`Budget untouched: ${policy.budgetRemaining}`);
    } else {
      lines.push("Action \u2192 SKIP (nothing worth it)");
      lines.push(`Budget untouched: ${policy.budgetRemaining}`);
    }
    lines.push("Reason");
    decision.reasons.forEach((r) => lines.push(r));
    return lines.join("\n");
  }

  // src/content/page-model.ts
  var BOILER = 'header,nav,footer,aside,[role="navigation"],[role="complementary"],[role="contentinfo"],[aria-hidden="true"]';
  var CHROME_HINT = /(^|[-_\s])(share|shared|social|related|recommend|comment|comments|disqus|tag|tags|subscribe|newsletter|cookie|consent|breadcrumb|author-bio|bio|promo|advert|ad|sponsor|sidebar|menu|nav|footer|widget|meta|pagination|pager|more-posts|back|prev|next)([-_\s]|$)/i;
  var READ_MORE = /(read more|continue reading|read the rest|full story|keep reading|read on)\b/i;
  var BLOCK_SEL = "h1,h2,h3,h4,h5,h6,p,blockquote,pre,figure";
  function clamp01(n) {
    return Math.min(1, Math.max(0, n));
  }
  function wordsOf(el) {
    if (!el) return 0;
    const text = (el.textContent || "").trim();
    return text ? text.split(/\s+/).length : 0;
  }
  function hintOf(el) {
    return `${el.className || ""} ${el.id || ""}`.toString().toLowerCase();
  }
  function isBoiler(el) {
    if (!el) return false;
    try {
      return Boolean(el.closest(BOILER)) || CHROME_HINT.test(hintOf(el));
    } catch {
      return false;
    }
  }
  function proseWords(el) {
    let total = 0;
    el.querySelectorAll("p, blockquote, pre").forEach((p) => {
      if (isBoiler(p)) return;
      total += Math.min(wordsOf(p), 2e3);
    });
    return total;
  }
  function linkWords(el) {
    let total = 0;
    el.querySelectorAll("a").forEach((a) => {
      total += wordsOf(a);
    });
    return total;
  }
  function metaContent2(doc, names) {
    for (const name of names) {
      const el = doc.querySelector(`meta[property="${name}"],meta[name="${name}"]`);
      const content = el?.getAttribute("content")?.trim();
      if (content) return content;
    }
    return "";
  }
  var DECOR_HINT = /(^|[-_\s])(avatar|icon|logo|emoji|sprite|badge|gravatar|favicon|spinner|placeholder|advert|ad|banner|pixel|tracking)([-_\s]|$)/i;
  function isContentImage(img, ogImage) {
    if (DECOR_HINT.test(hintOf(img))) return false;
    if (img.parentElement && DECOR_HINT.test(hintOf(img.parentElement))) return false;
    const src = img.src || img.getAttribute("src") || "";
    const ogTail = ogImage ? ogImage.replace(/^https?:\/\//, "").split("?")[0] : "";
    if (ogTail && src && src.replace(/^https?:\/\//, "").startsWith(ogTail)) return true;
    if (img.closest("figure")) return true;
    if (/image/i.test(img.getAttribute("itemprop") || "")) return true;
    const width = Number(img.naturalWidth) || Number(img.getAttribute("width")) || 0;
    if (width && width < 120) return false;
    if (width >= 300) return true;
    if ((img.getAttribute("alt") || "").trim().length >= 15) return true;
    return false;
  }
  function contentImageCount(scope, ogImage) {
    return Array.from(scope.querySelectorAll("img")).filter((im) => isContentImage(im, ogImage)).length;
  }
  function numericPagination(doc) {
    if (doc.querySelector('.pagination, .page-numbers, [class*="pagination" i], nav[aria-label*="pag" i]')) return true;
    const nums = Array.from(doc.querySelectorAll('nav a, [class*="pagination" i] a')).filter(
      (a) => /^\d{1,3}$/.test((a.textContent || "").trim())
    );
    return nums.length >= 2;
  }
  function repeatedCards(doc) {
    let best = 0;
    doc.querySelectorAll('main, [role="main"], section, ul, ol, div').forEach((parent) => {
      if (isBoiler(parent)) return;
      const cards = Array.from(parent.children).filter((kid) => {
        if (isBoiler(kid)) return false;
        const w = wordsOf(kid);
        if (w < 8 || w > 320) return false;
        const hasHeading = Boolean(kid.querySelector("h2,h3,h4"));
        const hasMedia = Boolean(kid.querySelector("img, picture, video"));
        const titledLink = Array.from(kid.querySelectorAll("a")).some((a) => (a.textContent || "").trim().length >= 15);
        return (hasHeading || titledLink) && (hasMedia || titledLink);
      });
      if (cards.length > best) best = cards.length;
    });
    return best;
  }
  function organizationScore(doc) {
    const typeStr = schemaTypes(doc).join(" ");
    const articleType = /article|blogposting|newsarticle|techarticle|scholarlyarticle/.test(typeStr);
    let score = 0;
    if (!articleType && /organization|corporation|localbusiness|professionalservice/.test(typeStr)) score += 0.5;
    const ogType = metaContent2(doc, ["og:type"]).toLowerCase();
    if (ogType === "website") score += 0.2;
    const footer = (doc.querySelector("footer")?.textContent || "").toLowerCase();
    if (/\b(llc|inc|corp|corporation|company|gmbh|ltd|limited|studio|agency|consulting|solutions|software development|enterprises)\b/i.test(footer)) {
      score += 0.4;
    }
    const navText = Array.from(doc.querySelectorAll("nav a, header a")).map((a) => (a.textContent || "").toLowerCase()).join(" ");
    if (/(portfolio|pricing|services|careers|case study|clients|our work|solutions)/.test(navText)) score += 0.3;
    if (/person/.test(typeStr) || doc.querySelector('[rel="author"], [itemprop="author"]')) score -= 0.4;
    if (doc.querySelector('link[type="application/rss+xml"], link[type="application/atom+xml"]')) score -= 0.1;
    return clamp01(score);
  }
  function previewPenalty(el) {
    let penalty = 0;
    const readMore = el.querySelector("a");
    el.querySelectorAll("a").forEach((a) => {
      if (READ_MORE.test((a.textContent || "").trim())) penalty = Math.max(penalty, 0.8);
    });
    void readMore;
    const parent = el.parentElement;
    if (parent) {
      const siblings = Array.from(parent.children).filter((c) => {
        if (c === el || isBoiler(c)) return false;
        const w = wordsOf(c);
        const titled = Boolean(c.querySelector("h2,h3,h4")) || Array.from(c.querySelectorAll("a")).some((a) => (a.textContent || "").trim().length >= 20);
        return w >= 15 && w <= 500 && titled && Boolean(c.querySelector("a"));
      });
      if (siblings.length >= 2) penalty = Math.max(penalty, 0.6);
    }
    return penalty;
  }
  function elementValue(option, weights) {
    let value = 0;
    for (const [signal, weight] of Object.entries(weights)) value += weight * (option.scores[signal] ?? 0);
    return value;
  }
  function classify(doc) {
    let pageProse = 0;
    doc.querySelectorAll("p, blockquote, pre").forEach((p) => {
      if (!isBoiler(p)) pageProse += Math.min(wordsOf(p), 2e3);
    });
    const best = contentContainer(doc);
    const bestProse = proseWords(best);
    const singleFocus = clamp01(bestProse / Math.max(1, pageProse));
    const substance = clamp01(pageProse / 600);
    const ogArticle = metaContent2(doc, ["og:type"]) === "article" ? 1 : 0;
    const articleTag = doc.querySelector("article") ? 1 : 0;
    const profilePage = metaContent2(doc, ["og:type"]).toLowerCase() === "profile";
    const articleCount = doc.querySelectorAll("article").length;
    const feedCards = clamp01((repeatedCards(doc) - 1) / 3);
    const pagination = numericPagination(doc) ? 1 : 0;
    const linkDensity = (() => {
      const total = wordsOf(doc.body);
      return total ? linkWords(doc.body) / total : 1;
    })();
    const navHeavy = clamp01(linkDensity * 2);
    const lowSubstance = 1 - substance;
    const title = metaContent2(doc, ["og:title", "twitter:title"]) || (doc.querySelector("h1")?.textContent || "").trim();
    const titleAlign = title ? Array.from(doc.querySelectorAll("h1")).some((h) => (h.textContent || "").trim().toLowerCase() === title.toLowerCase()) ? 1 : 0 : 0;
    const mainRegion = doc.querySelector('main, [role="main"]') ?? doc.body ?? doc.documentElement;
    const readMore = clamp01(
      Array.from(mainRegion.querySelectorAll("a")).filter((a) => READ_MORE.test((a.textContent || "").trim())).length / 2
    );
    const linkedHeadings = clamp01(mainRegion.querySelectorAll("h2 a, h3 a, h4 a").length / 4);
    const articles = Array.from(doc.querySelectorAll("article"));
    const dominantArticle = pageProse > 0 && articles.length ? clamp01(Math.max(...articles.map((a) => proseWords(a))) / pageProse) : 0;
    const controlCount = doc.querySelectorAll(
      'input, textarea, select, button, [role="button"], [contenteditable="true"]'
    ).length;
    const paragraphCount = doc.querySelectorAll("p").length;
    const controlHeavy = clamp01(controlCount / Math.max(1, controlCount + paragraphCount));
    const org = organizationScore(doc);
    const bodyVisibleWords = (doc.body?.innerText || "").trim().split(/\s+/).filter(Boolean).length;
    const bodyTextWords = (doc.body?.textContent || "").trim().split(/\s+/).filter(Boolean).length;
    const visibleRatio = bodyTextWords > 0 ? clamp01(bodyVisibleWords / bodyTextWords) : 1;
    const weights = {
      substance: 0.3,
      singleFocus: 0.25,
      titleAlign: 0.15,
      ogArticle: 0.15,
      articleTag: 0.15,
      feedCards: 0.5,
      pagination: 0.4,
      manyArticles: 0.4,
      readMore: 0.45,
      linkedHeadings: 0.3,
      lowSubstance: 0.35,
      navHeavy: 0.3,
      manyExternals: 0.2,
      controlHeavy: 0.5,
      organization: 0.5,
      hiddenContent: 0.5,
      dominantArticle: 0.4
    };
    const mk = (kind, scores) => {
      const confidence = clamp01(elementValue({ id: kind, kind, cost: 0, scores }, weights));
      return { id: kind, kind, cost: 0, scores: { ...scores, confidence } };
    };
    const options = [
      // A short page (bio card, landing) or a brand/organization page cannot be
      // "the content", however well titled its single block is.
      pageProse >= 200 && org < 0.5 && !profilePage && visibleRatio >= 0.5 ? mk("content", { substance, singleFocus, titleAlign, ogArticle, articleTag, dominantArticle }) : mk("content", { substance: 0, singleFocus: 0, titleAlign: 0, ogArticle: 0, articleTag: 0, dominantArticle: 0 }),
      mk("feed", { feedCards, pagination, manyArticles: clamp01((articleCount - 1) / 3), readMore, linkedHeadings }),
      mk("landing", { lowSubstance, navHeavy, manyExternals: navHeavy, controlHeavy, organization: org, hiddenContent: 1 - visibleRatio }),
      mk("app", { lowSubstance, manyExternals: navHeavy, controlHeavy, hiddenContent: 1 - visibleRatio }),
      mk("brand", { organization: org, lowSubstance })
    ];
    const policy = { budgetRemaining: 1, maxCost: 0, minConfidence: 0.35, weights };
    return { decision: decide(options, policy), options, policy };
  }
  function pickRoot(doc, tailWords = []) {
    const sels = [
      "article",
      '[role="article"]',
      "main",
      '[role="main"]',
      ".post-content",
      ".entry-content",
      ".article-body",
      '[itemtype*="Article"]'
    ];
    const seen = /* @__PURE__ */ new Set();
    const ogImage = metaContent2(doc, ["og:image"]);
    const entries = [];
    const add = (el) => {
      if (!el || seen.has(el) || isBoiler(el)) return;
      seen.add(el);
      const w = proseWords(el);
      if (w < 160) return;
      const total = wordsOf(el);
      const ld = total ? linkWords(el) / total : 1;
      const parentProse = el.parentElement ? Math.max(1, proseWords(el.parentElement)) : w;
      const hasTitle = Boolean(el.querySelector("h1,h2"));
      let readableTail = 0;
      if (tailWords.length) {
        const text = (el.textContent || "").toLowerCase();
        let hit = 0;
        for (const word of tailWords) if (text.includes(word)) hit += 1;
        readableTail = hit / tailWords.length;
      }
      const contentImages = contentImageCount(el, ogImage);
      const totalImages = el.querySelectorAll("img").length;
      const scores = {
        substance: clamp01(w / 900),
        focus: clamp01(w / parentProse),
        linkClean: 1 - clamp01(ld * 2),
        titleAlign: hasTitle ? 1 : 0,
        notPreview: 1 - previewPenalty(el),
        readableTail,
        contentMedia: contentImages > 0 || Boolean(el.querySelector("video,audio")) ? 1 : 0,
        imageClean: totalImages ? contentImages / totalImages : 1
      };
      entries.push({
        el,
        option: {
          id: `root-${entries.length}`,
          kind: "content-root",
          cost: 0,
          scores
        }
      });
    };
    sels.forEach((sel) => doc.querySelectorAll(sel).forEach((el) => add(el)));
    let generic = contentContainer(doc);
    for (let i = 0; i < 3 && generic; i++) {
      add(generic);
      generic = generic.parentElement;
    }
    const weights = {
      substance: 0.22,
      focus: 0.22,
      linkClean: 0.18,
      titleAlign: 0.13,
      notPreview: 0.25,
      readableTail: 0.3,
      contentMedia: 0.12,
      imageClean: 0.08
    };
    const options = entries.map(({ option }) => {
      const confidence = clamp01(elementValue(option, weights));
      return { ...option, scores: { ...option.scores, confidence } };
    });
    const byId = new Map(entries.map((e, i) => [options[i].id, e.el]));
    const policy = { budgetRemaining: 1, maxCost: 0, minConfidence: 0.45, weights };
    const decision = decide(options, policy);
    const element = decision.kind === "select" && decision.optionId ? byId.get(decision.optionId) : void 0;
    return { decision, option: element ? { ...options.find((o) => o.id === decision.optionId), element } : void 0, options, policy };
  }
  function blockScore(el) {
    const tag = el.tagName.toLowerCase();
    const words = wordsOf(el);
    const ld = words ? linkWords(el) / words : 1;
    const hint = hintOf(el);
    let score = 0.35;
    if (/^h[1-6]$/.test(tag) && words >= 2) score += 0.1;
    if (tag === "p" || tag === "blockquote" || tag === "pre" || tag === "figure") score += 0.2;
    score += Math.min(0.5, words / 120);
    score -= Math.min(0.6, ld);
    if (CHROME_HINT.test(hint)) score -= 0.6;
    if (READ_MORE.test((el.textContent || "").trim()) && words < 30) score -= 0.5;
    return clamp01(score);
  }
  function boundaries(root) {
    const blocks = Array.from(root.querySelectorAll(BLOCK_SEL)).filter((b) => {
      if (isBoiler(b)) return false;
      const parent = b.parentElement;
      if (parent && parent.closest("blockquote, figure, li")) return false;
      return wordsOf(b) > 0;
    });
    const options = blocks.map((el, i) => {
      const score = blockScore(el);
      return { id: `b${i}`, kind: "content-block", cost: 0, scores: { content: score, confidence: score } };
    });
    const policy = { budgetRemaining: 1, maxCost: 0, minConfidence: 0.45, weights: { content: 1 } };
    const slate = selectMany(options, policy, options.length);
    const kept = new Set(slate.picks.map((p) => p.option.id));
    const keptEls = blocks.filter((_, i) => kept.has(`b${i}`));
    const decision = {
      kind: keptEls.length ? "select" : "skip_all",
      optionId: keptEls.length ? `b${blocks.indexOf(keptEls[0])}` : null,
      action: keptEls.length ? "content-block" : "skip",
      value: slate.picks[0]?.value ?? 0,
      reasons: slate.picks.length ? [`kept ${keptEls.length}/${blocks.length} content blocks`, ...slate.picks[0]?.reasons ?? []] : ["no block met the content threshold"],
      budgetAfter: 1,
      escalated: false
    };
    let endEl = keptEls[keptEls.length - 1] ?? blocks[blocks.length - 1] ?? null;
    if (endEl) {
      const startIdx = blocks.indexOf(endEl);
      for (let i = startIdx + 1; i < blocks.length && i <= startIdx + 6; i++) {
        const block = blocks[i];
        const tag = block.tagName.toLowerCase();
        if (/^h[1-6]$/.test(tag)) break;
        if (isBoiler(block) || CHROME_HINT.test(hintOf(block))) break;
        const words = wordsOf(block);
        const density = words ? linkWords(block) / words : 1;
        if (words < 8 || density > 0.25) break;
        endEl = block;
      }
    }
    return { start: keptEls[0] ?? blocks[0] ?? null, end: endEl, decision, policy, kept: keptEls.length, total: blocks.length };
  }
  function authorCandidates(doc, root) {
    const out = [];
    const push = (value, score = 0, source = "") => {
      const v = (value || "").trim();
      if (!v || v.length > 120) return;
      out.push({ value: v, score, source });
    };
    push(metaContent2(doc, ["article:author", "author"]), 0.95, "meta-author");
    push(doc.querySelector('[itemprop="author"] [itemprop="name"], [itemprop="author"]')?.textContent, 0.85, "itemprop-author");
    push(doc.querySelector('[rel="author"]')?.textContent, 0.8, "rel-author");
    if (root) {
      const byline = root.querySelector('[class*="author" i], [class*="byline" i], [class*="written-by" i]');
      push(byline?.textContent, 0.7, "byline");
    }
    const meta = doc.querySelector('[class*="author" i], [class*="byline" i]');
    push(meta?.textContent, 0.5, "page-author-element");
    return out;
  }
  function pickAuthor(doc, root) {
    const candidates = authorCandidates(doc, root);
    if (!candidates.length) return { value: "", decision: null, policy: null };
    const options = candidates.map((c, i) => ({
      id: `author-${i}`,
      kind: "author",
      cost: 0,
      scores: { signal: c.score, confidence: c.score },
      meta: { value: c.value, source: c.source }
    }));
    const policy = { budgetRemaining: 1, maxCost: 0, minConfidence: 0.4, weights: { signal: 1 } };
    const decision = decide(options, policy);
    const winner = decision.kind === "select" ? options.find((o) => o.id === decision.optionId)?.meta : void 0;
    return { value: winner?.value ?? "", decision, policy };
  }
  function fingerprint2(title, text) {
    let h = 2166136261;
    const norm = (title + "\n" + text).toLowerCase().replace(/\s+/g, " ").slice(0, 8e3);
    for (let i = 0; i < norm.length; i++) {
      h ^= norm.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return ("0000000" + (h >>> 0).toString(16)).slice(-8);
  }
  function schemaTypes(doc) {
    const out = [];
    doc.querySelectorAll('script[type="application/ld+json"]').forEach((node) => {
      let data;
      try {
        data = JSON.parse(node.textContent || "null");
      } catch {
        return;
      }
      const walk = (value) => {
        if (!value) return;
        if (Array.isArray(value)) {
          value.forEach(walk);
          return;
        }
        if (typeof value !== "object") return;
        const record = value;
        const t = record["@type"];
        if (typeof t === "string") out.push(t.toLowerCase());
        else if (Array.isArray(t)) t.forEach((x) => typeof x === "string" && out.push(x.toLowerCase()));
        for (const nested of Object.values(record)) walk(nested);
      };
      walk(data);
    });
    return out;
  }
  function pickType(doc, root) {
    const types = schemaTypes(doc);
    const has = (re) => types.some((t) => re.test(t)) ? 1 : 0;
    const og = metaContent2(doc, ["og:type"]).toLowerCase();
    const hEntry = Boolean(doc.querySelector('.h-entry, [class~="h-entry"], article.h-entry'));
    const hasVideo = Boolean(
      doc.querySelector('video, iframe[src*="youtube"], iframe[src*="vimeo"], iframe[src*="player"], [itemprop="video"], meta[property="og:video"]')
    );
    const hasAudio = Boolean(
      doc.querySelector('audio, [itemprop="audio"], meta[property*="audio"], iframe[src*="spotify"], iframe[src*="anchor.fm"], iframe[src*="podcast"]')
    );
    const scope = root ?? doc;
    const ogImage = metaContent2(doc, ["og:image"]);
    const contentImgs = contentImageCount(scope, ogImage);
    const paraCount = scope.querySelectorAll("p").length;
    const hasCode = Boolean(scope.querySelector("pre, pre code, code"));
    const hasDiscussion = Boolean(doc.querySelector('form, textarea, [class*="comment" i]'));
    const weights = { schema: 0.7, og: 0.4, media: 0.4, gallery: 0.3, code: 0.3, discussion: 0.3 };
    const mk = (type2, scores) => {
      const confidence = clamp01(elementValue({ id: type2, kind: type2, cost: 0, scores }, weights));
      return { id: type2, kind: type2, cost: 0, scores: { ...scores, confidence } };
    };
    const options = [
      mk("article", { schema: has(/article|blogposting|newsarticle|techarticle/) ? 1 : hEntry ? 0.8 : 0, og: og.startsWith("article") ? 1 : 0 }),
      mk("paper", { schema: has(/scholarlyarticle|report|thesis/) ? 1 : 0, og: og === "book" ? 1 : 0 }),
      mk("video", { schema: has(/videoobject/) ? 1 : 0, og: og.startsWith("video") ? 1 : 0, media: hasVideo ? 1 : 0 }),
      mk("audio", { schema: has(/audioobject|podcastepisode|podcastseries/) ? 1 : 0, og: og.startsWith("music") ? 1 : 0, media: hasAudio ? 1 : 0 }),
      mk("gallery", { schema: has(/imagegallery|imageobject/) ? 1 : 0, gallery: contentImgs >= 4 && paraCount <= 4 ? 1 : 0 }),
      mk("code", { schema: has(/softwaresourcecode|softwareapplication/) ? 1 : 0, code: hasCode ? 1 : 0 }),
      mk("discussion", { schema: has(/discussionforumposting|question/) ? 1 : 0, discussion: hasDiscussion ? 1 : 0 })
    ];
    const policy = { budgetRemaining: 1, maxCost: 0, minConfidence: 0.35, weights };
    const decision = decide(options, policy);
    const type = decision.kind === "select" ? decision.action : "article";
    return { decision, policy, options, type };
  }
  function pickMedia(doc, root) {
    const sel = 'video, audio, iframe[src*="youtube"], iframe[src*="vimeo"], iframe[src*="player"], iframe[src*="spotify"], iframe[src*="anchor.fm"], [itemprop="video"], [itemprop="audio"]';
    return (root ?? doc).querySelector(sel) || doc.querySelector(sel);
  }
  function lastContentFigure(root, ogImage) {
    const figures = Array.from(root.querySelectorAll("figure")).filter((f) => contentImageCount(f, ogImage) > 0);
    return figures.length ? figures[figures.length - 1] : null;
  }
  function eligibility(input) {
    const weights = {
      kindConfidence: 0.25,
      rootConfidence: 0.25,
      boundRatio: 0.2,
      substance: 0.2,
      author: 0.05,
      media: 0.05
    };
    const scores = {
      kindConfidence: input.kindConfidence,
      rootConfidence: input.rootConfidence,
      boundRatio: input.boundRatio,
      substance: input.substance,
      author: input.authorPresent,
      media: input.mediaPresent
    };
    const confidence = clamp01(elementValue({ id: "render", kind: "tip", cost: 0, scores }, weights));
    const options = [{ id: "render", kind: "tip", cost: 0, scores: { ...scores, confidence } }];
    const policy = { budgetRemaining: 1, maxCost: 0, minConfidence: 0.45, weights };
    return { decision: decide(options, policy), policy, options };
  }
  function mapPage(rootNode = document) {
    const doc = rootNode.documentElement ? rootNode : document;
    const classified = classify(doc);
    const kind = classified.decision.kind === "select" ? classified.decision.action : "unknown";
    const lines = [`PAGE KIND \u2192 ${kind.toUpperCase()}`, ...classified.decision.reasons.map((r) => `  ${r}`)];
    const empty = {
      kind,
      kindDecision: classified.decision,
      contentType: "unknown",
      typeDecision: null,
      eligibility: null,
      root: null,
      rootDecision: null,
      start: null,
      end: null,
      media: null,
      anchor: null,
      author: "",
      authorDecision: null,
      title: "",
      canonical: "",
      siteName: "",
      wordCount: 0,
      fingerprint: "",
      links: [],
      candidates: classified.options.map((o) => ({ id: o.id, kind: o.kind, cost: o.cost, context: o.id, scores: o.scores })),
      trace: lines.join("\n")
    };
    const kindConfidence = clamp01(classified.decision.value);
    if (kind !== "content") return empty;
    const reader = extractContent();
    const tailWords = (reader?.excerptTail || "").toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, " ").split(/\s+/).filter((w) => w.length > 3).slice(-120);
    const picked = pickRoot(doc, tailWords);
    const root = picked.option?.element ?? null;
    if (picked.decision.kind === "select" && picked.policy) {
      lines.push("");
      lines.push(renderTrace(picked.decision, picked.options, picked.policy));
    }
    const effectiveRoot = root ?? contentContainer(doc);
    const bounds = boundaries(effectiveRoot);
    lines.push("");
    lines.push(`CONTENT BOUNDS \u2192 ${bounds.start?.tagName.toLowerCase() ?? "none"} \u2026 ${bounds.end?.tagName.toLowerCase() ?? "none"}`);
    bounds.decision.reasons.forEach((r) => lines.push(`  ${r}`));
    const author = pickAuthor(doc, effectiveRoot);
    if (author.decision && author.policy) {
      lines.push("");
      lines.push(renderTrace(author.decision, [], author.policy).split("\n")[0]);
      author.decision.reasons.forEach((r) => lines.push(`  author: ${r}`));
    }
    const media = pickMedia(doc, effectiveRoot);
    const type = pickType(doc, effectiveRoot);
    const galleryFigure = lastContentFigure(effectiveRoot, metaContent2(doc, ["og:image"]));
    const anchor = (type.type === "video" || type.type === "audio") && media ? media : type.type === "gallery" && galleryFigure ? galleryFigure : bounds.end;
    lines.push("");
    lines.push(`CONTENT TYPE \u2192 ${type.type.toUpperCase()}`);
    type.decision.reasons.forEach((r) => lines.push(`  ${r}`));
    const canonical = doc.querySelector('link[rel="canonical"]')?.getAttribute("href") || doc.location?.href || "";
    const title = metaContent2(doc, ["og:title", "twitter:title"]) || (effectiveRoot.querySelector("h1,h2")?.textContent || "").trim() || (doc.querySelector("h1")?.textContent || "").trim() || doc.title || "Untitled";
    const text = (effectiveRoot.textContent || "").trim();
    const wordCount = text ? text.split(/\s+/).filter(Boolean).length : 0;
    const elig = eligibility({
      kindConfidence,
      rootConfidence: clamp01(picked.decision.value),
      boundRatio: bounds.total ? bounds.kept / bounds.total : 0,
      substance: clamp01(wordCount / 600),
      authorPresent: author.value ? 1 : 0,
      mediaPresent: media ? 1 : 0
    });
    lines.push("");
    lines.push(renderTrace(elig.decision, elig.options, elig.policy));
    const links = Array.from(effectiveRoot.querySelectorAll("a[href]")).map((a) => a.href).filter((href) => /^https?:/.test(href)).filter((href, i, all) => all.indexOf(href) === i).slice(0, 50);
    return {
      ...empty,
      contentType: type.type,
      typeDecision: type.decision,
      eligibility: elig.decision,
      root: effectiveRoot,
      rootDecision: picked.decision,
      start: bounds.start,
      end: bounds.end,
      media,
      anchor,
      author: author.value,
      authorDecision: author.decision,
      title,
      canonical: canonicalContentUrl(canonical, doc.location?.href || ""),
      siteName: metaContent2(doc, ["og:site_name"]) || (doc.location?.hostname || "").replace(/^www\./, ""),
      wordCount,
      fingerprint: fingerprint2(title, text),
      links,
      candidates: picked.options.map((o) => ({
        id: o.id,
        kind: o.kind,
        cost: o.cost,
        context: `${o.id} words=?`,
        scores: o.scores
      })),
      trace: lines.join("\n")
    };
  }

  // src/content/guard.ts
  function isTippableUrl(href) {
    try {
      const url = new URL(href);
      return url.protocol === "http:" || url.protocol === "https:";
    } catch {
      return false;
    }
  }

  // src/content/tip-card.ts
  var CARD_ID = "nibgate-card";
  var HOST_ATTR = "data-nibgate-widget";
  var statusEl = null;
  function fontUrl(file) {
    try {
      return chrome.runtime.getURL(`fonts/${file}`);
    } catch {
      return "";
    }
  }
  function parseCssColor(value) {
    const parts = String(value || "").replace(/[^\d.,/ ]/g, " ").trim().split(/[\s,/]+/).filter(Boolean).map((part) => Number(part));
    if (parts.length < 3 || parts.some((part) => Number.isNaN(part))) return null;
    return { r: parts[0], g: parts[1], b: parts[2], a: parts.length > 3 ? parts[3] : 1 };
  }
  function relativeLuminance(color) {
    const linear = (channel) => {
      const c = Math.min(255, Math.max(0, channel)) / 255;
      return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
    };
    return 0.2126 * linear(color.r) + 0.7152 * linear(color.g) + 0.0722 * linear(color.b);
  }
  function withAlpha(color, alpha) {
    return `rgba(${Math.round(color.r)}, ${Math.round(color.g)}, ${Math.round(color.b)}, ${alpha})`;
  }
  function sanitizeFontStack(stack) {
    const families = String(stack || "").split(",").map((family) => family.trim().replace(/[^A-Za-z0-9 .'_"+-]/g, "").slice(0, 80)).filter((family) => family.length > 1);
    return families.join(", ");
  }
  function opaqueBackground(start) {
    let node = start;
    while (node) {
      const background = window.getComputedStyle(node).backgroundColor;
      const parsed = parseCssColor(background);
      if (parsed && parsed.a > 0.9) return background;
      node = node.parentElement;
    }
    return "rgb(255, 255, 255)";
  }
  function pageVisual(container) {
    const fallback = {
      background: "rgb(255, 255, 255)",
      foreground: "rgb(10, 10, 10)"
    };
    const themeAttribute = String(document.documentElement.dataset.theme || "").toLowerCase();
    const background = opaqueBackground(container);
    const bodyStyle = window.getComputedStyle(document.body);
    const foreground = parseCssColor(bodyStyle.color) ? bodyStyle.color : fallback.foreground;
    const luminance = relativeLuminance(parseCssColor(background) || { r: 255, g: 255, b: 255, a: 1 });
    const darkByLuminance = luminance < 0.39;
    const pageIsDark = themeAttribute === "dark" || themeAttribute !== "light" && darkByLuminance;
    const pageFont = sanitizeFontStack(bodyStyle.fontFamily);
    const parsedSize = Number.parseFloat(bodyStyle.fontSize || "");
    const bodySize = Number.isFinite(parsedSize) ? Math.min(17, Math.max(12.5, parsedSize)) : 14;
    const foregroundColor = parseCssColor(foreground) || parseCssColor(fallback.foreground);
    const light = !pageIsDark;
    return {
      background: light ? background : `rgba(${foregroundColor.r},${foregroundColor.g},${foregroundColor.b},0.03)`,
      foreground: light ? foreground : withAlpha(foregroundColor, 0.95),
      muted: withAlpha(foregroundColor, 0.72),
      border: withAlpha(foregroundColor, 0.22),
      font: pageFont ? `${pageFont}, 'Kumbh Sans','ABC Favorit',system-ui,sans-serif` : `'Kumbh Sans','ABC Favorit',system-ui,sans-serif`,
      size: `${bodySize}px`
    };
  }
  function applyPageVisual(host, container) {
    const visual = pageVisual(container);
    host.style.setProperty("--wc-bg", visual.background);
    host.style.setProperty("--wc-fg", visual.foreground);
    host.style.setProperty("--wc-muted", visual.muted);
    host.style.setProperty("--wc-border", visual.border);
    host.style.setProperty("--wc-font", visual.font);
    host.style.setProperty("--wc-size", visual.size);
  }
  var themeObserver = null;
  function watchPageVisual(host, container) {
    try {
      themeObserver?.disconnect();
      themeObserver = new MutationObserver(() => {
        try {
          applyPageVisual(host, container);
        } catch {
        }
      });
      themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme", "class", "style"] });
      themeObserver.observe(document.body, { attributes: true, attributeFilter: ["data-theme", "class", "style"] });
      themeObserver.observe(container, { attributes: true, attributeFilter: ["data-theme", "class", "style"] });
    } catch {
    }
  }
  function shadowStyles() {
    const kumbh = fontUrl("KumbhSans-Regular.woff2");
    const kumbh600 = fontUrl("KumbhSans-SemiBold.woff2");
    const kumbh700 = fontUrl("KumbhSans-Bold.woff2");
    return `
    @font-face { font-family:'Kumbh Sans'; src:url('${kumbh}') format('woff2'); font-weight:400; }
    @font-face { font-family:'Kumbh Sans'; src:url('${kumbh600}') format('woff2'); font-weight:600; }
    @font-face { font-family:'Kumbh Sans'; src:url('${kumbh700}') format('woff2'); font-weight:700; }
    :host { all: initial; display: block; width: 100%; flex: 0 0 100%; --bg:#f4f4f0; --surface:#ffffff; --surface-2:#f0eee6; --border:#11111124; --fg:#0a0a0a; --muted:#44423d; --accent:#7c9a6d; --accent-ink:#10110e; --gold:#ffc900; --danger:#ff3e30; }
    @media (prefers-color-scheme: dark) {
      :host { --bg:#171813; --surface:#20221c; --surface-2:#242820; --border:#f3efe729; --fg:#f4f4f0; --muted:#b9b2a6; --accent:#a9c69a; --danger:#ff5b4d; }
    }
    /* Slim coffee trigger: the only thing that renders in-page. Everything
       about money lives in the extension window. */
    .tipbtn { display:inline-flex; align-items:center; gap:8px; box-sizing:border-box; cursor:pointer; margin:24px 0; max-width:640px;
      font-family:var(--wc-font, 'Kumbh Sans','ABC Favorit',system-ui,sans-serif); font-size:var(--wc-size, 14px); font-weight:700;
      background:var(--accent); color:var(--accent-ink); border:0; border-radius:999px; padding:10px 18px; }
    .tipbtn:hover { filter:brightness(1.05); }
    .tipbtn svg { flex:none; display:block; }
    .tipbtn:disabled { opacity:.6; cursor:default; filter:none; }
    [data-tip-status] { font-size:.86em; color:var(--accent); margin:8px 0 24px; min-height:1.2em; max-width:640px;
      font-family:var(--wc-font, 'Kumbh Sans','ABC Favorit',system-ui,sans-serif); }
  `;
  }
  function cardMarkup(input) {
    return `
    <style>${shadowStyles()}</style>
    <div id="${CARD_ID}">
      <button class="tipbtn" data-open-tip aria-label="Tip the creator"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 10h13v5a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4v-5z"/><path d="M17 11h1.5a2.5 2.5 0 0 1 0 5H17"/><path d="M8 7c0-1.2.9-1.2.9-2.4M12 7c0-1.2.9-1.2.9-2.4"/></svg>Tip the creator</button>
      <div data-tip-status></div>
    </div>`;
  }
  async function assessState() {
    if (!isTippableUrl(window.location.href)) {
      try {
        document.documentElement.setAttribute("data-nibgate-kind", "platform");
      } catch {
      }
      return null;
    }
    const map = mapPage();
    try {
      document.documentElement.setAttribute("data-nibgate-kind", map.kind);
      document.documentElement.setAttribute("data-nibgate-type", map.contentType);
      document.documentElement.setAttribute("data-nibgate-eligible", map.eligibility?.kind === "select" ? "1" : "0");
      document.documentElement.setAttribute("data-nibgate-reason", map.kindDecision.reasons[0] || "");
    } catch {
    }
    const eligible = map.eligibility ? map.eligibility.kind === "select" : map.kind === "content";
    const placementEnd = map.anchor ?? map.end;
    let content = null;
    if (map.kind === "content" && eligible && placementEnd) {
      content = {
        url: window.location.href.split("#")[0],
        canonicalUrl: map.canonical || window.location.href.split("#")[0],
        title: map.title,
        author: map.author,
        siteName: map.siteName
      };
    } else if (map.kind === "content" && eligible) {
      const fallback = extractContent();
      if (fallback) content = fallback;
    }
    if (!content && (map.kind === "unknown" || map.kind === "content" && !eligible)) {
      try {
        const fallback = extractContent();
        const words = (document.body?.innerText || "").trim().split(/\s+/).filter(Boolean).length;
        if (fallback && words >= 200) {
          const state2 = [
            `URL: ${window.location.href.split("#")[0]}`,
            `Title: ${map.title || document.title || ""}`,
            `Site: ${map.siteName || ""}`,
            `Detected kind: ${map.kind} (${map.kindDecision.reasons[0] || "no reason"})`,
            `Word count: ${words}`,
            `Byline present: ${map.author ? `yes (${map.author})` : "no"}`,
            `Paragraphs: ${document.querySelectorAll("article p, main p, p").length}`,
            `Excerpt: ${(document.body?.innerText || "").replace(/\s+/g, " ").trim().slice(0, 600)}`
          ].join("\n").slice(0, 4e3);
          const verdict = await chrome.runtime.sendMessage({ type: "JEV_CLASSIFY", state: state2 });
          try {
            document.documentElement.setAttribute("data-nibgate-jev", String(verdict?.probability ?? ""));
          } catch {
          }
          if (verdict?.ok && Number(verdict.probability) >= 0.65) {
            content = fallback;
          }
        }
      } catch {
      }
    }
    if (!content) return null;
    const pageWallet = recipientWalletFromPage();
    const hasSdk = hasNibgateSdk();
    let isMainnet = false;
    try {
      const stored = await chrome.storage.local.get(["nibgateNetwork", "nibTipNetwork"]);
      isMainnet = stored.nibgateNetwork === "mainnet" || stored.nibTipNetwork === "mainnet";
    } catch {
    }
    let state = hasSdk ? "resolved" : "unknown";
    try {
      const assessment = await chrome.runtime.sendMessage({ type: "ASSESS", content, pageWallet, hasSdk });
      if (assessment?.resolution?.state === "resolved") state = "resolved";
      else if (assessment) state = "held";
    } catch {
      state = hasSdk ? "resolved" : "held";
    }
    return { content, pageWallet, hasSdk, isMainnet, state, end: map.kind === "content" ? map.end : null, kind: map.kind };
  }
  function renderCard(input, runId) {
    if (document.querySelector(`[${HOST_ATTR}]`)) return;
    const host = document.createElement("div");
    host.setAttribute(HOST_ATTR, "");
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = cardMarkup(input);
    const card = shadow.getElementById(CARD_ID);
    if (card) card.setAttribute("data-run", runId);
    statusEl = shadow.querySelector("[data-tip-status]");
    shadow.querySelector("[data-open-tip]")?.addEventListener("click", () => {
      openTipWindow(input.content, input.pageWallet);
    });
    const container = input.end?.parentElement ?? contentContainer();
    try {
      applyPageVisual(host, container);
    } catch {
    }
    let inserted = false;
    if (input.end?.parentNode) {
      try {
        input.end.parentNode.insertBefore(host, input.end.nextSibling);
        inserted = true;
      } catch {
      }
    }
    if (!inserted) {
      const blocks = Array.from(container.querySelectorAll("h1, h2, h3, p, blockquote, pre, figure"));
      for (let i = blocks.length - 1; i >= 0; i--) {
        const block = blocks[i];
        if (!(block instanceof HTMLElement) || block.closest(`[${HOST_ATTR}]`) || isBoilerplateZone(block)) continue;
        const text = (block.textContent || "").trim();
        if (text.length < 80) continue;
        const style = window.getComputedStyle(block);
        if (style.display === "none" || style.visibility === "hidden") continue;
        const parent = block.parentNode;
        if (!parent) continue;
        try {
          parent.insertBefore(host, block.nextSibling);
          inserted = true;
          break;
        } catch {
          continue;
        }
      }
    }
    if (!inserted) {
      try {
        container.appendChild(host);
      } catch {
        document.body.appendChild(host);
      }
    }
    shadow.querySelector("[data-open-tip]")?.addEventListener("click", () => {
      openTipWindow(input.content, input.pageWallet);
    });
    watchPageVisual(host, container);
  }
  async function openTipWindow(content, pageWallet) {
    const say = (text) => {
      if (statusEl) statusEl.textContent = text;
    };
    if (!chrome.runtime?.id) {
      say("Extension reloaded \u2014 refresh the page and try again.");
      return;
    }
    let candidateWallets = [];
    try {
      candidateWallets = recipientWalletsFromPage();
    } catch {
      candidateWallets = [];
    }
    let opened;
    try {
      opened = await chrome.runtime.sendMessage({ type: "TIP_OPEN", content, pageWallet, candidateWallets, hasSdk: hasNibgateSdk() });
    } catch {
      say("Extension error \u2014 reopen the popup and try again.");
      return;
    }
    if (!opened?.ok) {
      say(opened?.error || "Tip failed to start.");
      return;
    }
    const id = String(opened.id || "");
    say("Continue in the extension window\u2026");
    for (let i = 0; i < 120; i++) {
      await new Promise((r) => setTimeout(r, 1500));
      if (!chrome.runtime?.id) return;
      let res = null;
      try {
        res = await chrome.runtime.sendMessage({ type: "TIP_RESULT", id });
      } catch {
        return;
      }
      if (!res || !res.done) continue;
      if (res.ok) {
        if (res.held) {
          const waiting = res.heldCount ? ` (${res.heldCount} waiting \xB7 $${Number(res.heldTotal || 0).toFixed(2)})` : "";
          say(`Held for the creator \u2713 ${String(res.txHash || "").slice(0, 10)}\u2026${waiting}`);
        } else {
          say(`Tipped \u2713 ${String(res.txHash || "").slice(0, 10)}\u2026`);
        }
      } else {
        say(res.error || "Cancelled.");
      }
      return;
    }
    say("Still waiting \u2014 reopen the extension window or check popup history.");
  }
  async function main() {
    let keepalive = null;
    try {
      keepalive = chrome.runtime.connect({ name: "nibgate-keepalive" });
      document.addEventListener("pagehide", () => {
        try {
          keepalive?.disconnect();
        } catch {
        }
        keepalive = null;
      });
    } catch {
    }
    const myRun = Math.random().toString(36).slice(2);
    window.__nibgateCardRun = myRun;
    try {
      await chrome.runtime.sendMessage({ type: "CONTENT_READY", url: window.location.href });
    } catch {
    }
    const input = await assessState();
    if (window.__nibgateCardRun !== myRun) return;
    document.documentElement.setAttribute("data-nibgate-assessed", "1");
    if (input) renderCard(input, myRun);
  }
  main();
})();
